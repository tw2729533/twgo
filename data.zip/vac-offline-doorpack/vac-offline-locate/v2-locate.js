/**
 * 高雄榮服處離線地圖 v2.3.10 — 勾責任區連動服務網
 * 彈窗加入排訪、篩選連動、排訪點擊置中、測繪鈕、清單卡頓／重疊。
 * H-MAP-01。個資僅本機，不上傳。勿改 GeoJSON 里界。
 */
(function () {
  "use strict";

  var GPS_COLOR = "#1976d2";
  var MEASURE_COLOR = "#e65100";
  var LOW_COLOR = "#ef6c00";
  var VISIT_PENDING = "#1565c0"; /* 待受訪 */
  var VISIT_QUEUED = "#6a1b9a";  /* 排訪中 */
  var VISIT_DONE = "#546e7a";    /* 已訪 */
  var DB_NAME = "vac-offline-locate-v2";
  var DB_VER = 1;
  var listCap = 250;
  var LIST_CAP_CHOICES = [250, 500, 1000, 2000, 0];
  var GEO_TIMEOUT = 12000;
  var OPTIMIZE_WARN_N = 30;

  var map = null;
  var gpsMarker = null;
  var gpsCircle = null;
  var measureVerts = [];
  var measureLayer = null;
  var measuring = false;
  var speedKmh = 15;
  var veterans = [];
  var doorExact = Object.create(null);
  var doorFuzzy = Object.create(null);
  var suggestByRoad = Object.create(null);
  var suggestRoadNames = [];
  var suggestIndexGen = 0;
  var suggestTimer = 0;
  var suggestActive = -1;
  var doorCount = 0;
  var doorReady = false;
  var maskName = true;
  var cluster = null;
  var toastTimer = 0;
  var tileHintShown = false;
  var pendingDoorText = null;
  var customLocateMode = false;
  var myPosKind = null; /* 'gps' | 'custom' | 'addr' | null */
  var locMenuOpen = false;
  var vetLayerToastShown = false;
  var liAliasRows = []; /* {town, old, new, ambiguous, note} */
  var liXrefExact = Object.create(null);
  var liXrefFuzzy = Object.create(null);
  var liXrefMissing = [];
  var LS_CUSTOM = "vac-v2-custom-pos";
  var LS_VISIT_Q = "vac-v2-visit-queue";
  var LS_VISIT_DONE = "vac-v2-visit-done";
  var LS_VISIT_PANEL = "vac-v2-visit-panel";
  var LS_ROUTE_START = "vac-v2-route-start-mode";
  var LS_TOOLS = "vac-v2-tools-collapsed";
  var LS_LIST_FILTER = "vac-v2-list-filter";
  var toolsCollapsed = false;
  var OSRM_ENDPOINT = "https://router.project-osrm.org/route/v1/bicycle";
  var OSRM_TIMEOUT_MS = 12000;
  var routeSegs = [];
  var routeGen = 0;
  var routeLoading = false;
  var doorMeta = { version: "", source: "", lastDelta: "", exactCount: 0, fuzzyCount: 0 };
  var pendingDoorMode = "replace";
  var syncingZoneNets = false;
  /* 責任區 → 預設服務網（可再依訪視名單／村里編輯補齊） */
  /* v2.3 visit */
  var visitQueue = []; /* {id} pending visit order */
  var visitedList = []; /* {id, at} completed visits */
  var visitRouteLayer = null;
  var visitRouteSegs = [];
  var visitRouteGen = 0;
  var visitRouteLoading = false;
  var birthdayMonth = ""; /* "" = all, "1".."12" */
  var listZoneFilter = "";
  var listNetFilter = "";
  var listBdayFilter = "";
  var listStatusFilter = ""; /* "" | fail | low | ok */
  var showVisitPanel = true;
  var showDonePanel = false;
  var routeStartMode = "mypos"; /* mypos | first */
  var expandedAddrs = Object.create(null);
  var rightTab = "visit"; /* visit | village */
  var visitRouteTimer = 0;
  var listTimer = 0;
  var markerTimer = 0;
  var cachedFilter = null;
  var focusVisitId = null;

  /* H-MAP-01：對齊 kh_town_codes.csv（省市 64＝高雄市） */
  var KH_CITY_BY_CODE = { "64": "高雄市" };
  var KH_TOWN_BY_CODE = {
    "6400100": "鹽埕區", "6400200": "鼓山區", "6400300": "左營區", "6400400": "楠梓區",
    "6400500": "三民區", "6400600": "新興區", "6400700": "前金區", "6400800": "苓雅區",
    "6400900": "前鎮區", "6401000": "旗津區", "6401100": "小港區", "6401200": "鳳山區",
    "6401300": "林園區", "6401400": "大寮區", "6401500": "大樹區", "6401600": "大社區",
    "6401700": "仁武區", "6401800": "鳥松區", "6401900": "岡山區", "6402000": "橋頭區",
    "6402100": "燕巢區", "6402200": "田寮區", "6402300": "阿蓮區", "6402400": "路竹區",
    "6402500": "湖內區", "6402600": "茄萣區", "6402700": "永安區", "6402800": "彌陀區",
    "6402900": "梓官區", "6403000": "旗山區", "6403100": "美濃區", "6403200": "六龜區",
    "6403300": "甲仙區", "6403400": "杉林區", "6403500": "內門區", "6403600": "茂林區",
    "6403700": "桃源區", "6403800": "那瑪夏區"
  };

  function $(id) { return document.getElementById(id); }

  function toHalfWidth(s) {
    return String(s == null ? "" : s).replace(/[\uFF01-\uFF5E]/g, function (ch) {
      return String.fromCharCode(ch.charCodeAt(0) - 0xFEE0);
    }).replace(/\u3000/g, " ");
  }

  function normalizeAddr(raw) {
    var s = toHalfWidth(raw).trim();
    s = s.replace(/\s+/g, "");
    s = s.replace(/[﹒．]/g, ".");
    s = s.replace(/之號/g, "之");
    s = s.replace(/號之/g, "之");
    s = s.replace(/[0-9]+樓之?[0-9]*/g, "");
    s = s.replace(/[一二三四五六七八九十廿卅百]+樓之?[0-9]*/g, "");
    s = s.replace(/地下室/g, "");
    s = s.replace(/[0-9]+F[0-9\-]*/gi, "");
    s = s.replace(/[0-9]+鄰/g, "");
    s = s.replace(/區[\u4e00-\u9fff]{1,8}里/, "區");
    s = s.replace(/台灣省?/g, "");
    s = s.replace(/臺灣省?/g, "");
    if (s.indexOf("高雄市") !== 0 && /[區鄉鎮市]/.test(s)) {
      s = "高雄市" + s.replace(/^高雄/, "");
    }
    return s;
  }

  function fuzzyKey(raw) {
    var s = normalizeAddr(raw);
    var m = s.match(/([^\d]+?(?:路|街|大道|道|巷))(?:[0-9]+段)?(?:[0-9]+巷)?(?:[0-9]+弄)?([0-9]+)(?:之[0-9]+)?號?/);
    if (!m) {
      m = s.match(/([^\d]{1,12}(?:村|鄰))?([0-9]+)(?:之[0-9]+)?號/);
      if (!m) return "";
    }
    var district = "";
    var dm = s.match(/高雄市?([\u4e00-\u9fff]{1,4}[區鄉鎮市])/);
    if (dm) district = dm[1];
    var road = (m[1] || "").replace(/^.*市/, "").replace(/^.*[區鄉鎮市]/, "");
    var num = m[2] || m[m.length - 1];
    if (!road || !num) return "";
    return district + "|" + road + "|" + num;
  }

  function fuzzyKeyVariants(raw) {
    var s = normalizeAddr(raw);
    var out = [];
    var seen = Object.create(null);
    function add(v) {
      if (!v || seen[v]) return;
      seen[v] = true;
      out.push(v);
    }
    add(fuzzyKey(s));
    add(fuzzyKey(s.replace(/之[0-9]+/g, "")));
    add(fuzzyKey(s.replace(/[0-9]+段/g, "")));
    add(fuzzyKey(s.replace(/[0-9]+弄/g, "")));
    add(fuzzyKey(s.replace(/[0-9]+巷[0-9]*弄?/g, "")));
    add(fuzzyKey(s.replace(/臺/g, "台")));
    add(fuzzyKey(s.replace(/台/g, "臺")));
    return out;
  }

  function exactKeyVariants(raw) {
    var base = normalizeAddr(raw);
    var out = [];
    var seen = Object.create(null);
    function add(v) {
      v = String(v || "").trim();
      if (!v || seen[v]) return;
      seen[v] = true;
      out.push(v);
    }
    add(base);
    add(base.replace(/臺/g, "台"));
    add(base.replace(/台/g, "臺"));
    add(base.replace(/號$/, ""));
    if (base && base.charAt(base.length - 1) !== "號") add(base + "號");
    add(base.replace(/之[0-9]+號/g, "號"));
    add(base.replace(/號之[0-9]+/g, "號"));
    add(base.replace(/[0-9]+鄰/g, ""));
    add(base.replace(/[0-9]+段/g, ""));
    /* 去里後再正規化一次（normalizeAddr 已去里，這裡再清殘段） */
    add(base.replace(/[\u4e00-\u9fff]{1,8}里/, ""));
    return out;
  }

  function hasDoorNumber(raw) {
    var s = toHalfWidth(raw).replace(/\s+/g, "");
    return /[0-9]+號/.test(s) || /[0-9]+(?:之[0-9]+)?(?:號)?$/.test(s.replace(/.*[區鄉鎮市]/, "")) || /[0-9]+(?:巷|弄|號)/.test(s);
  }

  function extractTownLi(raw) {
    var s = toHalfWidth(raw).replace(/\s+/g, "");
    /* 高雄市本身以「市」結尾，勿把「高雄市」當成行政區；里對照表皆為區／鄉／鎮 */
    var m = s.match(/高雄市([\u4e00-\u9fff]{1,4}[區鄉鎮])([\u4e00-\u9fff]{1,8}里)/);
    if (!m) m = s.match(/([\u4e00-\u9fff]{1,4}[區鄉鎮])([\u4e00-\u9fff]{1,8}里)/);
    if (!m) return null;
    return { town: m[1], li: m[2] };
  }

  function lookupLiAlias(town, li) {
    var hits = [];
    for (var i = 0; i < liAliasRows.length; i++) {
      var r = liAliasRows[i];
      if (r.town === town && r.old === li) hits.push(r);
    }
    if (!hits.length) return null;
    var news = [];
    var seen = Object.create(null);
    var ambiguous = false;
    for (var j = 0; j < hits.length; j++) {
      if (hits[j].ambiguous) ambiguous = true;
      if (!seen[hits[j].new]) {
        seen[hits[j].new] = true;
        news.push(hits[j].new);
      }
    }
    if (news.length > 1) ambiguous = true;
    /* 原名保留且僅自身：不算替換 */
    if (!ambiguous && news.length === 1 && news[0] === li) return null;
    return { old: li, news: news, ambiguous: ambiguous, town: town };
  }

  function xrefRecFromDict(s) {
    var p = String(s || "").split("|");
    return { ot: p[0] || "", ol: p[1] || "", nt: p[2] || "", nl: p[3] || "" };
  }

  async function loadLiDoorXref() {
    var urls = ["samples/li-door-xref-115.json", "./samples/li-door-xref-115.json"];
    var data = null;
    for (var i = 0; i < urls.length; i++) {
      try {
        var res = await fetch(urls[i], { cache: "no-store" });
        if (!res.ok) continue;
        data = await res.json();
        if (data && (data.pairs || data.items)) break;
      } catch (e) { /* missing */ }
    }
    liXrefExact = Object.create(null);
    liXrefFuzzy = Object.create(null);
    liXrefMissing = [];
    if (!data) return;
    if (Array.isArray(data.missingLi)) liXrefMissing = data.missingLi.slice();
    var dict = data.dict || [];
    var pairs = data.pairs || [];
    var j, rec, k, fz, d;
    for (j = 0; j < pairs.length; j++) {
      k = pairs[j][0];
      d = dict[pairs[j][1]] || "";
      rec = xrefRecFromDict(d);
      rec.k = k;
      rec.amb = pairs[j][2] === 1;
      liXrefExact[k] = rec;
      fz = fuzzyKey("高雄市" + (rec.nt || rec.ot || "") + k);
      if (fz && !liXrefFuzzy[fz]) liXrefFuzzy[fz] = rec;
    }
  }

  function lookupLiDoorXref(addr) {
    var vars = exactKeyVariants(addr);
    var i, k, road, rec;
    for (i = 0; i < vars.length; i++) {
      k = vars[i];
      if (liXrefExact[k]) return liXrefExact[k];
      road = String(k || "").replace(/^高雄市/, "").replace(/^[\u4e00-\u9fff]{1,4}[區鄉鎮]/, "");
      if (road && liXrefExact[road]) return liXrefExact[road];
    }
    var fz = fuzzyKeyVariants(addr);
    for (i = 0; i < fz.length; i++) {
      rec = liXrefFuzzy[fz[i]];
      if (rec) return rec;
    }
    return null;
  }

  function liInMissingScan(li) {
    if (!li) return false;
    for (var i = 0; i < liXrefMissing.length; i++) {
      if (li === liXrefMissing[i] || li.indexOf(liXrefMissing[i]) === 0 || liXrefMissing[i].indexOf(li) === 0) return true;
    }
    return false;
  }

  function classifyAddrFail(addr, alias) {
    var xref = lookupLiDoorXref(addr);
    var townLi = extractTownLi(addr);
    var oldLi = (alias && alias.old) || (townLi && townLi.li) || "";
    var newLi = "";
    var newTown = "";
    if (xref) {
      newLi = xref.nl || "";
      newTown = xref.nt || "";
    }
    var kind = "not-in-index";
    var reason = "地址對不到門牌（對照表也無此號）";
    if (!hasDoorNumber(addr)) {
      kind = "no-number";
      reason = "無門牌號碼";
    } else if (xref) {
      kind = "xref-not-in-pack";
      reason = "對照表有此號，門牌索引沒有";
      if (newTown || newLi) reason += "；對照新里＝" + (newTown + newLi);
    } else if (alias && alias.ambiguous) {
      if (liInMissingScan(oldLi)) {
        kind = "xref-missing-scan";
        reason = "舊里一對多，對照表缺頁（掃描檔：" + oldLi + "）。請改填：" + alias.news.join("／");
      } else {
        kind = "old-li-split";
        reason = "舊里一對多，對照表無此號。請改填：" + alias.news.join("／");
      }
    } else if (alias && !alias.ambiguous && alias.news && alias.news.length === 1) {
      kind = "old-li-mapped";
      reason = "已套用舊里對照：" + alias.old + "→" + alias.news[0] + "；仍無門牌命中";
    } else if (oldLi && liInMissingScan(oldLi)) {
      kind = "xref-missing-scan";
      reason = "對照表缺頁（掃描檔：" + oldLi + "）";
    }
    return {
      kind: kind,
      reason: reason,
      xrefNew: (newTown + newLi) || "",
      xrefOld: xref ? (xref.ot + xref.ol) : (oldLi || "")
    };
  }

  function applyLiAliasToAddr(raw, alias) {
    if (!alias || alias.ambiguous || !alias.news || alias.news.length !== 1) return raw;
    var neu = alias.news[0];
    if (neu === alias.old) return raw;
    var s = String(raw);
    var idx = s.indexOf(alias.town + alias.old);
    if (idx >= 0) {
      return s.slice(0, idx) + alias.town + neu + s.slice(idx + (alias.town + alias.old).length);
    }
    return s.replace(alias.old, neu);
  }

  function parseLiAliasCsv(text) {
    var rows = parseCsv(text);
    var out = [];
    if (!rows.length) return out;
    var start = 0;
    var h0 = String(rows[0][0] || "");
    if (h0.indexOf("行政區") >= 0 || h0.indexOf("舊里") >= 0) start = 1;
    for (var i = start; i < rows.length; i++) {
      var r = rows[i];
      if (!r || r.length < 3) continue;
      var town = String(r[0] || "").trim();
      var old = String(r[1] || "").trim();
      var neu = String(r[2] || "").trim();
      var amb = String(r[3] || "").trim();
      var note = String(r[4] || "").trim();
      if (!town || !old || !neu) continue;
      out.push({
        town: town,
        old: old,
        new: neu,
        ambiguous: amb === "是" || amb.toLowerCase() === "true" || amb === "1",
        note: note
      });
    }
    return out;
  }

  async function loadLiAlias() {
    var urls = ["samples/li-alias-kh.csv", "./samples/li-alias-kh.csv"];
    for (var i = 0; i < urls.length; i++) {
      try {
        var res = await fetch(urls[i], { cache: "no-store" });
        if (!res.ok) continue;
        var text = await res.text();
        var parsed = parseLiAliasCsv(text);
        if (parsed.length) {
          liAliasRows = parsed;
          return;
        }
      } catch (e) { /* file:// or missing */ }
    }
    /* 內建最小後備（與 samples/li-alias-kh.csv 同步之關鍵列） */
    if (!liAliasRows.length) {
      liAliasRows = parseLiAliasCsv(
        "行政區,舊里,新里,是否一對多,備註\n" +
        "左營區,中南里,中北里,否,\n" +
        "左營區,祥和里,屏山里,否,\n" +
        "鼓山區,龍水里,北美術館里,是,\n" +
        "鼓山區,龍水里,南美術館里,是,\n" +
        "湖內區,公館里,公舘里,否,"
      );
    }
  }

  function haversineKm(a, b) {
    var R = 6371;
    var dLat = (b.lat - a.lat) * Math.PI / 180;
    var dLng = (b.lng - a.lng) * Math.PI / 180;
    var la1 = a.lat * Math.PI / 180;
    var la2 = b.lat * Math.PI / 180;
    var h = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(la1) * Math.cos(la2) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
    return 2 * R * Math.asin(Math.min(1, Math.sqrt(h)));
  }

  function maskLast2(name) {
    var n = String(name || "");
    if (!n) return "";
    if (n.length <= 1) return "○";
    if (n.length === 2) return n.charAt(0) + "○";
    return n.slice(0, n.length - 2) + "○○";
  }

  function displayName(name) {
    return maskName ? maskLast2(name) : String(name || "");
  }

  function toast(msg, kind, ms) {
    var el = $("vac-v2-toast");
    if (!el) return;
    el.textContent = msg;
    el.setAttribute("data-kind", kind || "info");
    el.classList.add("is-on");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.classList.remove("is-on"); }, ms || 4200);
  }

  function setBanner(msg, on) {
    var el = $("vac-v2-banner");
    if (!el) return;
    if (!on) { el.classList.remove("is-on"); el.textContent = ""; return; }
    el.textContent = msg;
    el.classList.add("is-on");
  }

  function setProgress(on, label, pct) {
    var el = $("vac-v2-progress");
    if (!el) return;
    if (!on) { el.classList.remove("is-on"); return; }
    el.classList.add("is-on");
    var t = el.querySelector(".lbl");
    var b = el.querySelector(".bar > i");
    if (t) t.textContent = label || "處理中…";
    if (b) b.style.width = Math.max(0, Math.min(100, pct || 0)) + "%";
  }

  function yieldUI() {
    return new Promise(function (r) { setTimeout(r, 0); });
  }

  function countRepl(s) {
    var n = 0;
    for (var i = 0; i < s.length; i++) if (s.charCodeAt(i) === 0xFFFD) n++;
    return n;
  }

  function scoreDecoded(text) {
    var s = 0;
    if (text.indexOf("姓名") >= 0) s += 12;
    if (text.indexOf("通訊地址") >= 0) s += 12;
    if (text.indexOf("責任區") >= 0) s += 6;
    if (text.indexOf("高雄") >= 0) s += 4;
    if (text.indexOf("地址") >= 0) s += 3;
    if (text.indexOf("緯度") >= 0 || text.indexOf("經度") >= 0) s += 4;
    if (text.indexOf("橫座標") >= 0) s += 8;
    if (text.indexOf("縱座標") >= 0) s += 6;
    if (text.indexOf("街路段") >= 0) s += 8;
    if (text.indexOf("鄉鎮市區代碼") >= 0) s += 6;
    if (text.indexOf("省市縣市代碼") >= 0) s += 4;
    if (/[\u4e00-\u9fff]/.test(text.slice(0, 4000))) s += 3;
    s -= countRepl(text) * 2;
    return s;
  }

  function tryDecode(bytes, label) {
    try { return new TextDecoder(label, { fatal: false }).decode(bytes); }
    catch (e) { return null; }
  }

  function decodeCsvBytes(buf) {
    var bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
    if (bytes.length >= 3 && bytes[0] === 0xEF && bytes[1] === 0xBB && bytes[2] === 0xBF) {
      return { text: new TextDecoder("utf-8").decode(bytes.subarray(3)), enc: "utf-8-bom" };
    }
    if (bytes.length >= 2 && bytes[0] === 0xFF && bytes[1] === 0xFE) {
      return { text: new TextDecoder("utf-16le").decode(bytes.subarray(2)), enc: "utf-16le" };
    }
    var candidates = [
      { enc: "utf-8", text: tryDecode(bytes, "utf-8") },
      { enc: "big5", text: tryDecode(bytes, "big5") },
      { enc: "big5-hkscs", text: tryDecode(bytes, "big5-hkscs") }
    ];
    var best = null;
    for (var i = 0; i < candidates.length; i++) {
      if (!candidates[i].text) continue;
      var sc = scoreDecoded(candidates[i].text);
      if (!best || sc > best.sc) best = { enc: candidates[i].enc, text: candidates[i].text, sc: sc };
    }
    if (!best) return { text: new TextDecoder("utf-8").decode(bytes), enc: "utf-8" };
    return { text: best.text, enc: best.enc };
  }

  function parseCsv(text) {
    if (!text) return [];
    if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);
    var rows = [];
    var row = [];
    var cur = "";
    var q = false;
    for (var i = 0; i < text.length; i++) {
      var c = text.charAt(i);
      if (q) {
        if (c === '"') {
          if (text.charAt(i + 1) === '"') { cur += '"'; i++; }
          else q = false;
        } else cur += c;
      } else if (c === '"') {
        q = true;
      } else if (c === "," || c === "\t") {
        row.push(cur); cur = "";
      } else if (c === "\n") {
        row.push(cur); rows.push(row); row = []; cur = "";
      } else if (c !== "\r") {
        cur += c;
      }
    }
    if (cur.length || row.length) { row.push(cur); rows.push(row); }
    return rows.filter(function (r) {
      return r.some(function (x) { return String(x).trim() !== ""; });
    });
  }

  function rowsToObjects(rows) {
    if (!rows.length) return { headers: [], items: [] };
    var headers = rows[0].map(function (h) { return String(h || "").trim(); });
    var items = [];
    for (var i = 1; i < rows.length; i++) {
      var o = {};
      for (var j = 0; j < headers.length; j++) o[headers[j]] = rows[i][j] != null ? String(rows[i][j]) : "";
      o.__row = i + 1;
      items.push(o);
    }
    return { headers: headers, items: items };
  }

  function loadSheetJs() {
    return new Promise(function (resolve, reject) {
      if (window.XLSX && window.XLSX.read) { resolve(); return; }
      if (window.__vacSheetJsQ) { window.__vacSheetJsQ.push(function (err) { err ? reject(err) : resolve(); }); return; }
      window.__vacSheetJsQ = [function (err) { err ? reject(err) : resolve(); }];
      var s = document.createElement("script");
      s.src = "vendor/xlsx.full.min.js";
      s.async = true;
      s.onload = function () {
        var q = window.__vacSheetJsQ || [];
        window.__vacSheetJsQ = null;
        q.forEach(function (fn) { fn(); });
      };
      s.onerror = function () {
        var q = window.__vacSheetJsQ || [];
        window.__vacSheetJsQ = null;
        q.forEach(function (fn) { fn(new Error("無法載入 Excel 讀取元件，請改存成 CSV")); });
      };
      document.head.appendChild(s);
    });
  }

  function cleanImportCell(v) {
    if (v == null) return "";
    if (typeof v === "number") {
      if (!isFinite(v)) return "";
      if (Math.abs(v - Math.round(v)) < 1e-9) return String(Math.round(v));
      return String(v);
    }
    return String(v)
      .replace(/^\ufeff/, "")
      .replace(/[\u00a0\u200b\u200c\u200d\ufeff]/g, "")
      .replace(/[\r\n]+/g, " ")
      .replace(/\u3000/g, " ")
      .trim();
  }

  function excelFirstSheetGrid(buf) {
    var wb = window.XLSX.read(buf, { type: "array", cellDates: false, raw: false });
    if (!wb || !wb.SheetNames || !wb.SheetNames.length) throw new Error("Excel 沒有工作表");
    var name = wb.SheetNames[0];
    var sheet = wb.Sheets[name];
    var aoa = window.XLSX.utils.sheet_to_json(sheet, { header: 1, raw: false, defval: "" }) || [];
    var grid = aoa.map(function (row) { return (row || []).map(cleanImportCell); });
    return { name: name, extra: wb.SheetNames.length > 1 ? wb.SheetNames.slice(1) : [], grid: grid };
  }

  function isVeteranHeaderRow(cells) {
    var joined = (cells || []).map(function (h) { return String(h || "").replace(/\s+/g, ""); }).join("|");
    var hasName = /姓名|名字/.test(joined) || /(^|\|)name(\||$)/i.test(joined);
    var hasAddr = /通訊地址|地址|address/i.test(joined);
    return hasName && hasAddr;
  }

  function sliceFromVeteranHeader(rows) {
    var i, lim = Math.min(8, rows.length);
    for (i = 0; i < lim; i++) {
      if (isVeteranHeaderRow(rows[i])) return { start: i, rows: rows.slice(i) };
    }
    return { start: -1, rows: rows };
  }

  function twd97ToWgs84(x, y) {
    var a = 6378137.0;
    var b = 6356752.314245;
    var lng0 = 121 * Math.PI / 180;
    var k0 = 0.9999;
    var dx = 250000;
    x = Number(x) - dx;
    y = Number(y);
    var e = Math.sqrt(1 - (b * b) / (a * a));
    var M = y / k0;
    var mu = M / (a * (1 - Math.pow(e, 2) / 4 - 3 * Math.pow(e, 4) / 64 - 5 * Math.pow(e, 6) / 256));
    var e1 = (1 - Math.sqrt(1 - e * e)) / (1 + Math.sqrt(1 - e * e));
    var J1 = 3 * e1 / 2 - 27 * Math.pow(e1, 3) / 32;
    var J2 = 21 * Math.pow(e1, 2) / 16 - 55 * Math.pow(e1, 4) / 32;
    var J3 = 151 * Math.pow(e1, 3) / 96;
    var J4 = 1097 * Math.pow(e1, 4) / 512;
    var fp = mu + J1 * Math.sin(2 * mu) + J2 * Math.sin(4 * mu) + J3 * Math.sin(6 * mu) + J4 * Math.sin(8 * mu);
    var e2 = (e * e) / (1 - e * e);
    var C1 = e2 * Math.pow(Math.cos(fp), 2);
    var T1 = Math.pow(Math.tan(fp), 2);
    var R1 = a * (1 - e * e) / Math.pow(1 - e * e * Math.pow(Math.sin(fp), 2), 1.5);
    var N1 = a / Math.sqrt(1 - e * e * Math.pow(Math.sin(fp), 2));
    var D = x / (N1 * k0);
    var Q1 = N1 * Math.tan(fp) / R1;
    var Q2 = Math.pow(D, 2) / 2;
    var Q3 = (5 + 3 * T1 + 10 * C1 - 4 * C1 * C1 - 9 * e2) * Math.pow(D, 4) / 24;
    var Q4 = (61 + 90 * T1 + 298 * C1 + 45 * T1 * T1 - 252 * e2 - 3 * C1 * C1) * Math.pow(D, 6) / 720;
    var lat = fp - Q1 * (Q2 - Q3 + Q4);
    var Q5 = D;
    var Q6 = (1 + 2 * T1 + C1) * Math.pow(D, 3) / 6;
    var Q7 = (5 - 2 * C1 + 28 * T1 - 3 * C1 * C1 + 8 * e2 + 24 * T1 * T1) * Math.pow(D, 5) / 120;
    var lng = lng0 + (Q5 - Q6 + Q7) / Math.cos(fp);
    return { lat: lat * 180 / Math.PI, lng: lng * 180 / Math.PI };
  }

  function looksTwd97(x, y) {
    x = Number(x); y = Number(y);
    return x > 50000 && x < 400000 && y > 2300000 && y < 2900000;
  }

  function looksWgs84(lat, lng) {
    lat = Number(lat); lng = Number(lng);
    return lat > 20 && lat < 26.5 && lng > 118 && lng < 123;
  }

  function openDb() {
    return new Promise(function (resolve) {
      if (!window.indexedDB) { resolve(null); return; }
      var req = indexedDB.open(DB_NAME, DB_VER);
      req.onupgradeneeded = function () {
        var db = req.result;
        if (!db.objectStoreNames.contains("meta")) db.createObjectStore("meta");
        if (!db.objectStoreNames.contains("veterans")) db.createObjectStore("veterans");
        if (!db.objectStoreNames.contains("doorExact")) db.createObjectStore("doorExact");
        if (!db.objectStoreNames.contains("doorFuzzy")) db.createObjectStore("doorFuzzy");
      };
      req.onsuccess = function () { resolve(req.result); };
      req.onerror = function () { resolve(null); };
    });
  }

  function idbPut(store, key, val) {
    return openDb().then(function (db) {
      if (!db) return;
      return new Promise(function (res) {
        var tx = db.transaction(store, "readwrite");
        tx.objectStore(store).put(val, key);
        tx.oncomplete = function () { res(); };
        tx.onerror = function () { res(); };
      });
    });
  }

  function idbGet(store, key) {
    return openDb().then(function (db) {
      if (!db) return null;
      return new Promise(function (res) {
        var tx = db.transaction(store, "readonly");
        var r = tx.objectStore(store).get(key);
        r.onsuccess = function () { res(r.result != null ? r.result : null); };
        r.onerror = function () { res(null); };
      });
    });
  }

  function idbClearAll() {
    return openDb().then(function (db) {
      if (!db) return;
      return new Promise(function (res) {
        var tx = db.transaction(["meta", "veterans", "doorExact", "doorFuzzy"], "readwrite");
        tx.objectStore("meta").clear();
        tx.objectStore("veterans").clear();
        tx.objectStore("doorExact").clear();
        tx.objectStore("doorFuzzy").clear();
        tx.oncomplete = function () { res(); };
        tx.onerror = function () { res(); };
      });
    });
  }

  async function persistState() {
    try {
      await idbPut("veterans", "all", veterans);
      await idbPut("doorExact", "all", doorExact);
      await idbPut("doorFuzzy", "all", doorFuzzy);
      await idbPut("meta", "info", { doorCount: doorCount, doorReady: doorReady, doorMeta: doorMeta, t: Date.now() });
    } catch (e) { /* private mode */ }
  }

  async function restoreState() {
    try {
      var v = await idbGet("veterans", "all");
      var e = await idbGet("doorExact", "all");
      var f = await idbGet("doorFuzzy", "all");
      var m = await idbGet("meta", "info");
      if (Array.isArray(v) && v.length) {
        veterans = v.map(function (row) {
          if (row && row.birthMonth == null) {
            row.birthMonth = parseBirthMonth(row.birthMonth || row.birthday || "");
          }
          return row;
        });
      }
      if (e && typeof e === "object") {
        doorExact = e;
        scheduleSuggestRebuild();
      }
      if (f && typeof f === "object") doorFuzzy = f;
      if (m) {
        doorCount = m.doorCount || 0;
        doorReady = !!m.doorReady;
        if (m.doorMeta && typeof m.doorMeta === "object") doorMeta = m.doorMeta;
      }
    } catch (err) { /* ignore */ }
  }

  function el(tag, attrs, kids) {
    var n = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        if (k === "class") n.className = attrs[k];
        else if (k === "text") n.textContent = attrs[k];
        else if (k === "html") n.innerHTML = attrs[k];
        else n.setAttribute(k, attrs[k]);
      });
    }
    (kids || []).forEach(function (c) { if (c) n.appendChild(c); });
    return n;
  }

  function filterSelect(id, label) {
    var wrap = el("label", { class: "vac-v2-flt-item" });
    wrap.appendChild(el("span", { text: label }));
    var sel = el("select", { id: id, "aria-label": label + "篩選" });
    var o = document.createElement("option");
    o.value = "";
    o.textContent = "全部";
    sel.appendChild(o);
    wrap.appendChild(sel);
    return wrap;
  }

  function uniqueSortedKeys(getRaw, formatFn) {
    var map = Object.create(null);
    for (var i = 0; i < veterans.length; i++) {
      var raw = String(getRaw(veterans[i]) || "").trim();
      var key = raw ? numKey(raw) : "__unset__";
      if (!map[key]) map[key] = raw;
    }
    var keys = Object.keys(map).sort(function (a, b) {
      if (a === "__unset__") return 1;
      if (b === "__unset__") return -1;
      return (Number(a) || 0) - (Number(b) || 0) || String(a).localeCompare(String(b), "zh-Hant");
    });
    return keys.map(function (k) {
      return { value: k === "__unset__" ? "__unset__" : k, label: k === "__unset__" ? "未指定" : (formatFn ? formatFn(map[k]) : map[k]) };
    });
  }

  function fillOneFilter(sel, items, current) {
    if (!sel) return;
    sel.textContent = "";
    var all = document.createElement("option");
    all.value = "";
    all.textContent = "全部";
    sel.appendChild(all);
    items.forEach(function (it) {
      var o = document.createElement("option");
      o.value = it.value;
      o.textContent = it.label;
      sel.appendChild(o);
    });
    var ok = false;
    for (var i = 0; i < sel.options.length; i++) if (sel.options[i].value === current) ok = true;
    sel.value = ok ? current : "";
  }

  function fillListFilters() {
    fillOneFilter($("vac-v2-flt-zone"), uniqueSortedKeys(function (v) { return v.zone; }, formatZone), listZoneFilter);
    fillOneFilter($("vac-v2-flt-net"), uniqueSortedKeys(function (v) { return v.net; }, formatNet), listNetFilter);
    var months = [];
    for (var m = 1; m <= 12; m++) months.push({ value: String(m), label: m + " 月" });
    fillOneFilter($("vac-v2-flt-bday"), months, listBdayFilter);
    if ($("vac-v2-flt-zone")) $("vac-v2-flt-zone").value = listZoneFilter;
    if ($("vac-v2-flt-net")) $("vac-v2-flt-net").value = listNetFilter;
    if ($("vac-v2-flt-bday")) $("vac-v2-flt-bday").value = listBdayFilter;
  }

  function persistListFilters() {
    try {
      localStorage.setItem(LS_LIST_FILTER, JSON.stringify({
        z: listZoneFilter, n: listNetFilter, b: listBdayFilter
      }));
    } catch (e) {}
  }

  function restoreListFilters() {
    try {
      var raw = localStorage.getItem(LS_LIST_FILTER);
      if (!raw) return;
      var o = JSON.parse(raw);
      if (!o || typeof o !== "object") return;
      listZoneFilter = o.z || "";
      listNetFilter = o.n || "";
      listBdayFilter = o.b || "";
      birthdayMonth = listBdayFilter;
    } catch (e) {}
  }

  function buildChrome() {
    var title = $("vac-app-title");
    if (title) {
      title.classList.add("vac-v2-titlebar");
      title.textContent = "";
      var b = document.createElement("b");
      b.textContent = "高雄市榮服處責任區地圖";
      b.title = "高雄市榮服處責任區地圖";
      title.appendChild(b);
    }

    var bar = el("div", { id: "vac-v2-toolbar", class: "vac-v2-toolbar", role: "toolbar", "aria-label": "定位與測繪工具" });
    bar.appendChild(el("button", { id: "vac-v2-tools-toggle", class: "vac-v2-tools-toggle", type: "button", "aria-expanded": "true", "aria-label": "收合工具列", text: "收合工具" }));
    var netPopBtn = $("vac-net-pop-btn");
    if (netPopBtn) {
      netPopBtn.style.left = "";
      netPopBtn.style.top = "";
      netPopBtn.style.right = "";
      netPopBtn.style.bottom = "";
      bar.appendChild(netPopBtn);
    }
    var locWrap = el("div", { id: "vac-v2-locate-wrap", class: "vac-v2-locate-wrap" });
    locWrap.appendChild(el("button", { id: "vac-v2-locate", class: "vac-v2-locate", type: "button", "aria-haspopup": "true", "aria-expanded": "false", "aria-label": "我的位置選單", text: "我的位置 ▾" }));
    var locMenu = el("div", { id: "vac-v2-locate-menu", class: "vac-v2-locate-menu", role: "menu", "aria-label": "我的位置" });
    locMenu.appendChild(el("button", { type: "button", role: "menuitem", "data-act": "gps", text: "GPS 定位" }));
    locMenu.appendChild(el("button", { type: "button", role: "menuitem", "data-act": "pin", text: "點地圖設定" }));
    var addrRow = el("div", { class: "vac-v2-locate-addr", role: "none" });
    addrRow.appendChild(el("div", { class: "vac-v2-locate-addr-lab", text: "出發地地址" }));
    addrRow.appendChild(el("input", { id: "vac-v2-addr-input", type: "text", autocomplete: "off", placeholder: "例：左營區博愛三路585號", role: "combobox", "aria-autocomplete": "list", "aria-expanded": "false", "aria-controls": "vac-v2-addr-suggest" }));
    addrRow.appendChild(el("div", { id: "vac-v2-addr-suggest", class: "vac-v2-addr-suggest", role: "listbox", hidden: "hidden" }));
    addrRow.appendChild(el("p", { id: "vac-v2-addr-err", class: "vac-v2-locate-addr-err", text: "" }));
    addrRow.appendChild(el("button", { type: "button", class: "vac-v2-locate-addr-ok", "data-act": "addr-ok", text: "設為出發地" }));
    locMenu.appendChild(addrRow);
    locMenu.appendChild(el("button", { type: "button", role: "menuitem", "data-act": "clear", text: "清除" }));
    locWrap.appendChild(locMenu);
    bar.appendChild(locWrap);
    var toolsBody = el("div", { id: "vac-v2-tools-body", class: "vac-v2-tools-body" });
    bar.appendChild(toolsBody);

    var measBox = el("div", { class: "vac-v2-tool-group is-measure", "aria-label": "測繪工具" });
    measBox.appendChild(el("span", { class: "vac-v2-tool-group-label", text: "測繪" }));
    measBox.appendChild(el("button", { id: "vac-v2-measure", type: "button", "aria-pressed": "false", "aria-label": "測繪模式", text: "開始測繪" }));
    var sp = el("label", { class: "vac-v2-speed" });
    sp.appendChild(document.createTextNode("時速"));
    sp.appendChild(el("input", { id: "vac-v2-speed", type: "number", min: "10", max: "25", value: "15", "aria-label": "騎車時速公里每小時" }));
    sp.appendChild(document.createTextNode("km/h"));
    measBox.appendChild(sp);
    measBox.appendChild(el("span", { id: "vac-v2-metrics", class: "vac-v2-metrics", text: "距離 —" }));
    measBox.appendChild(el("button", { id: "vac-v2-undo", type: "button", text: "復原末點", "aria-label": "復原最後一點" }));
    measBox.appendChild(el("button", { id: "vac-v2-clear-path", type: "button", text: "清除路徑", "aria-label": "清除測繪路徑" }));
    measBox.appendChild(el("button", { id: "vac-v2-done", type: "button", text: "完成", "aria-label": "結束測繪" }));
    toolsBody.appendChild(measBox);

    var visitBox = el("div", { class: "vac-v2-tool-group is-visit", "aria-label": "排訪路徑" });
    visitBox.appendChild(el("span", { class: "vac-v2-tool-group-label", text: "排訪" }));
    visitBox.appendChild(el("span", { id: "vac-v2-route-hint", class: "vac-v2-route-hint", text: "騎車路網（OSRM）" }));
    var startLab = el("label", { class: "vac-v2-start-tool", id: "vac-v2-start-lab" });
    startLab.appendChild(el("input", { type: "checkbox", id: "vac-v2-start-first" }));
    startLab.appendChild(document.createTextNode("無定位時以清單第 1 人為起點"));
    visitBox.appendChild(startLab);
    visitBox.appendChild(el("button", { id: "vac-v2-optimize", type: "button", text: "優化訪序", "aria-label": "一鍵優化訪序", title: "固定起點，僅未訪；nearest-neighbor＋2-opt 近似" }));
    visitBox.appendChild(el("button", { id: "vac-v2-export-visit", type: "button", text: "匯出 CSV", "aria-label": "匯出今日排訪 CSV" }));
    toolsBody.appendChild(visitBox);

    toolsBody.appendChild(el("button", { id: "vac-v2-wipe", class: "vac-v2-wipe", type: "button", text: "清本機個資", "aria-label": "清除本機個資" }));
    document.body.appendChild(bar);

    document.body.appendChild(el("div", { id: "vac-v2-hud", class: "vac-v2-hud", role: "status" }));
    document.body.appendChild(el("div", { id: "vac-v2-toast", class: "vac-v2-toast", role: "status", "aria-live": "polite" }));
    document.body.appendChild(el("div", { id: "vac-v2-banner", class: "vac-v2-banner", role: "status" }));
    var prog = el("div", { id: "vac-v2-progress", class: "vac-v2-progress", role: "status" });
    prog.appendChild(el("div", { class: "lbl", text: "處理中…" }));
    var barw = el("div", { class: "bar" });
    barw.appendChild(el("i"));
    prog.appendChild(barw);
    document.body.appendChild(prog);

    var legend = el("div", { id: "vac-v2-legend", class: "vac-v2-legend", role: "note", "aria-label": "圖標圖例" });
    function legendItem(color, label, dashed) {
      var row = el("div", { class: "vac-v2-legend-item" });
      var sw = el("span", { class: "vac-v2-legend-swatch" + (dashed ? " is-dash" : "") });
      sw.style.background = color;
      if (dashed) sw.style.borderStyle = "dashed";
      row.appendChild(sw);
      row.appendChild(el("span", { text: label }));
      return row;
    }
    legend.appendChild(legendItem(VISIT_PENDING, "待受訪", false));
    legend.appendChild(legendItem(VISIT_QUEUED, "排訪中", false));
    legend.appendChild(legendItem(VISIT_DONE, "已訪", false));
    legend.appendChild(legendItem(LOW_COLOR, "低信心", true));
    var legClose = el("button", { type: "button", class: "vac-v2-legend-close", id: "vac-v2-legend-close", "aria-label": "關閉圖例", text: "×" });
    legend.appendChild(legClose);
    document.body.appendChild(legend);

    var modal = el("div", { id: "vac-v2-mapmodal", class: "vac-v2-modal", role: "dialog", "aria-label": "門牌欄位對照" });
    var box = el("div", { class: "box" });
    var h3 = document.createElement("h3");
    h3.textContent = "匯入門牌 — 欄位對照";
    box.appendChild(h3);
    var p = document.createElement("p");
    p.style.color = "#555";
    p.style.margin = "0 0 8px";
    p.textContent = "正式門牌欄（H-MAP-01）已鎖定預設對照。個資只留在本機。請匯入 part1–13 切片，勿一次載入整份約 107MB。";
    box.appendChild(p);
    box.appendChild(el("div", { id: "vac-v2-map-headers", text: "" }));
    $("vac-v2-map-headers") && null;
    function addField(fid, label) {
      var lab = document.createElement("label");
      lab.setAttribute("for", fid);
      lab.textContent = label;
      box.appendChild(lab);
      box.appendChild(el("select", { id: fid }));
    }
    addField("vac-v2-col-addr", "地址欄（正式檔請留空＝組合高雄市＋區＋街路段＋巷弄號）");
    addField("vac-v2-col-lat", "緯度 / WGS84 Y");
    addField("vac-v2-col-lng", "經度 / WGS84 X");
    addField("vac-v2-col-x", "TWD97 X／橫座標");
    addField("vac-v2-col-y", "TWD97 Y／縱座標");
    var hint = document.createElement("p");
    hint.style.fontSize = "11px";
    hint.style.color = "#666";
    hint.textContent = "H-MAP-01：地址＝高雄市＋鄉鎮區名（由鄉鎮市區代碼）＋街路段＋巷＋弄＋號（村里／鄰不納入主索引）。座標＝橫／縱（TWD97 TM2）自動轉 WGS84。舊版完整地址＋緯度經度仍可用。";
    box.appendChild(hint);
    var rowbtns = el("div", { class: "rowbtns" });
    rowbtns.appendChild(el("button", { type: "button", class: "vac-v2-btn", id: "vac-v2-map-cancel", text: "取消" }));
    rowbtns.appendChild(el("button", { type: "button", class: "vac-v2-btn", id: "vac-v2-map-ok", text: "開始匯入索引" }));
    box.appendChild(rowbtns);
    modal.appendChild(box);
    document.body.appendChild(modal);
    var hdr = $("vac-v2-map-headers");
    if (hdr) { hdr.style.fontSize = "11px"; hdr.style.color = "#666"; hdr.style.marginBottom = "8px"; }

    setupRightVisitPanel();

    var layers = $("vac-layer-toggles");
    if (layers) {
      var lab = document.createElement("label");
      lab.style.cssText = "display:flex;align-items:center;gap:6px;margin:3px 0;cursor:pointer;";
      var cb = el("input", { type: "checkbox", id: "vac-layer-vet" });
      cb.checked = true;
      lab.appendChild(cb);
      lab.appendChild(el("span", { text: "訪視對象" }));
      layers.appendChild(lab);
    }

    document.body.appendChild(el("input", { id: "vac-v2-file-vet", type: "file", accept: ".csv,text/csv,.txt,text/plain,.xlsx,.xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", style: "display:none" }));
    document.body.appendChild(el("input", { id: "vac-v2-file-door", type: "file", accept: ".csv,text/csv,.txt,text/plain", style: "display:none" }));
    document.body.appendChild(el("input", { id: "vac-v2-file-doorpack", type: "file", accept: ".json,application/json", multiple: "multiple", style: "display:none" }));
    var wipeModal = el("div", { id: "vac-v2-wipe-modal", class: "vac-v2-modal", role: "dialog", "aria-label": "清本機個資" });
    var wipeBox = el("div", { class: "box" });
    var wh = document.createElement("h3");
    wh.textContent = "清本機個資";
    wipeBox.appendChild(wh);
    var wp = document.createElement("p");
    wp.style.margin = "0 0 8px";
    wp.style.color = "#555";
    wp.textContent = "將清除訪視對象名單與自訂位置。村里責任區編輯不受影響。";
    wipeBox.appendChild(wp);
    var wipeLab = document.createElement("label");
    wipeLab.style.cssText = "display:flex;align-items:flex-start;gap:8px;font-size:12px;margin:8px 0 12px;cursor:pointer;";
    var wipeCb = el("input", { type: "checkbox", id: "vac-v2-wipe-door" });
    wipeLab.appendChild(wipeCb);
    wipeLab.appendChild(document.createTextNode("一併清除門牌索引（預設不勾；勾選後需重新載入門牌包）"));
    wipeBox.appendChild(wipeLab);
    var wipeBtns = el("div", { class: "rowbtns" });
    wipeBtns.appendChild(el("button", { type: "button", class: "vac-v2-btn", id: "vac-v2-wipe-cancel", text: "取消" }));
    wipeBtns.appendChild(el("button", { type: "button", class: "vac-v2-btn", id: "vac-v2-wipe-ok", text: "確定清除" }));
    wipeBox.appendChild(wipeBtns);
    wipeModal.appendChild(wipeBox);
    document.body.appendChild(wipeModal);

    var passModal = el("div", { id: "vac-v2-pass-modal", class: "vac-v2-modal", role: "dialog", "aria-label": "管理者" });
    var passBox = el("div", { class: "box" });
    passBox.appendChild(el("h3", { id: "vac-v2-pass-title", text: "管理者" }));
    passBox.appendChild(el("p", { id: "vac-v2-pass-lead", text: "由管理者設定兩組不同密碼。" }));
    var oldLab = el("label", { id: "vac-v2-pass-old-lab", text: "目前管理者密碼" });
    oldLab.appendChild(el("input", { id: "vac-v2-pass-old", type: "password", autocomplete: "current-password" }));
    passBox.appendChild(oldLab);
    var pwLab = el("label", { id: "vac-v2-pass-new-lab", text: "設定管理者新密碼" });
    pwLab.appendChild(el("input", { id: "vac-v2-pass-new", type: "password", autocomplete: "new-password" }));
    passBox.appendChild(pwLab);
    var cfLab = el("label", { id: "vac-v2-pass-cf-lab", text: "再輸入一次" });
    cfLab.appendChild(el("input", { id: "vac-v2-pass-cf", type: "password", autocomplete: "new-password" }));
    passBox.appendChild(cfLab);
    var staffLab = el("label", { id: "vac-v2-pass-staff-lab", text: "設定載入內建門牌密碼(同仁共用)" });
    staffLab.appendChild(el("input", { id: "vac-v2-pass-staff", type: "password", autocomplete: "new-password" }));
    passBox.appendChild(staffLab);
    passBox.appendChild(el("p", { id: "vac-v2-pass-err", class: "vac-v2-pass-err", text: "" }));
    var passBtns = el("div", { class: "rowbtns" });
    passBtns.appendChild(el("button", { type: "button", class: "vac-v2-btn", id: "vac-v2-pass-cancel", text: "取消" }));
    passBtns.appendChild(el("button", { type: "button", class: "vac-v2-btn vac-v2-btn-import", id: "vac-v2-pass-ok", text: "確定" }));
    passBox.appendChild(passBtns);
    passModal.appendChild(passBox);
    document.body.appendChild(passModal);

    var noticeModal = el("div", { id: "vac-v2-notice-modal", class: "vac-v2-modal", role: "dialog", "aria-label": "門牌說明" });
    var noticeBox = el("div", { class: "box" });
    noticeBox.appendChild(el("h3", { id: "vac-v2-notice-title", text: "門牌索引" }));
    noticeBox.appendChild(el("p", { id: "vac-v2-notice-body", text: "" }));
    var noticeBtns = el("div", { class: "rowbtns" });
    noticeBtns.appendChild(el("button", { type: "button", class: "vac-v2-btn vac-v2-btn-import", id: "vac-v2-notice-ok", text: "知道了" }));
    noticeBox.appendChild(noticeBtns);
    noticeModal.appendChild(noticeBox);
    document.body.appendChild(noticeModal);
  }

  function setupRightVisitPanel() {
    var editor = $("vac-editor");
    if (!editor || $("vac-v2-visit-pane")) return;
    var headSpan = editor.querySelector(".vac-panel-head > span");
    if (headSpan) headSpan.textContent = "訪視";
    var tabBtn = $("vac-right-tab");
    if (tabBtn) tabBtn.textContent = "訪視";
    editor.setAttribute("aria-label", "訪視與排訪");

    var villageWrap = el("div", { id: "vac-v2-village-wrap", class: "vac-v2-village-wrap" });
    villageWrap.hidden = true;
    var move = [];
    for (var i = 0; i < editor.children.length; i++) {
      var ch = editor.children[i];
      if (ch.classList && ch.classList.contains("vac-panel-head")) continue;
      move.push(ch);
    }
    move.forEach(function (ch) { villageWrap.appendChild(ch); });

    var tabs = el("div", { class: "vac-v2-rtabs", role: "tablist" });
    tabs.appendChild(el("button", { type: "button", role: "tab", id: "vac-v2-tab-visit", class: "is-on", "aria-selected": "true", text: "訪視" }));
    tabs.appendChild(el("button", { type: "button", role: "tab", id: "vac-v2-tab-village", "aria-selected": "false", text: "村里編輯" }));

    var visitPane = el("div", { id: "vac-v2-visit-pane", class: "vac-v2-visit-pane", role: "tabpanel" });

    var sec = el("div", { id: "vac-v2-veterans", class: "vac-v2-veterans" });
    var headRow = el("div", { class: "vac-v2-import-head" });
    var h = document.createElement("h3");
    h.textContent = "訪視對象匯入";
    headRow.appendChild(h);
    headRow.appendChild(el("button", { type: "button", class: "vac-v2-linkbtn", id: "vac-v2-fold-import", text: "收合匯入工具", hidden: "hidden" }));
    sec.appendChild(headRow);
    var importBlock = el("div", { id: "vac-v2-import-block" });
    var acts1 = el("div", { class: "vac-v2-actions vac-v2-actions-door" });
    acts1.appendChild(el("button", { type: "button", class: "vac-v2-btn", id: "vac-v2-load-doorpack", text: "載入內建門牌" }));
    acts1.appendChild(el("button", { type: "button", class: "vac-v2-btn", id: "vac-v2-door-pass", text: "管理者", title: "管理者設定／變更兩組密碼（與同仁密碼必須不同）" }));
    acts1.appendChild(el("button", { type: "button", class: "vac-v2-btn", id: "vac-v2-imp-door", text: "匯入門牌CSV" }));
    acts1.appendChild(el("button", { type: "button", class: "vac-v2-btn vac-v2-btn-init", id: "vac-v2-init-visit", text: "初始化" }));
    importBlock.appendChild(acts1);
    var acts2 = el("div", { class: "vac-v2-actions vac-v2-actions-vet" });
    acts2.appendChild(el("button", { type: "button", class: "vac-v2-btn vac-v2-btn-fail", id: "vac-v2-export-fail", text: "匯出失敗 Excel" }));
    acts2.appendChild(el("button", { type: "button", class: "vac-v2-btn", id: "vac-v2-dl-sample", text: "下載示範 Excel" }));
    acts2.appendChild(el("button", { type: "button", class: "vac-v2-btn vac-v2-btn-import", id: "vac-v2-imp-vet", text: "匯入訪視對象 CSV／Excel" }));
    importBlock.appendChild(acts2);
    importBlock.appendChild(el("div", { id: "vac-v2-door-status", class: "vac-v2-door-status", text: "尚未載入全市門牌索引" }));
    var maskLab = document.createElement("label");
    maskLab.style.cssText = "display:flex;align-items:center;gap:6px;margin:4px 0;font-size:12px;cursor:pointer;";
    var maskCb = el("input", { type: "checkbox", id: "vac-v2-mask" });
    maskCb.checked = true;
    maskLab.appendChild(maskCb);
    maskLab.appendChild(document.createTextNode(" 姓名遮後兩字"));
    importBlock.appendChild(maskLab);
    sec.appendChild(importBlock);
    sec.appendChild(el("div", { class: "vac-v2-stats", id: "vac-v2-stats" }));
    sec.appendChild(el("input", { type: "search", id: "vac-v2-search", class: "vac-v2-search", placeholder: "搜尋姓名／地址", "aria-label": "搜尋訪視對象" }));
    var fltBar = el("div", { class: "vac-v2-filter-bar", id: "vac-v2-filter-bar" });
    fltBar.appendChild(filterSelect("vac-v2-flt-zone", "責任區"));
    fltBar.appendChild(filterSelect("vac-v2-flt-net", "服務網"));
    fltBar.appendChild(filterSelect("vac-v2-flt-bday", "生日月"));
    var capWrap = el("label", { class: "vac-v2-flt-item" });
    capWrap.appendChild(el("span", { text: "顯示筆數" }));
    var capSel = el("select", { id: "vac-v2-list-cap", "aria-label": "名單顯示筆數" });
    LIST_CAP_CHOICES.forEach(function (n) {
      var o = document.createElement("option");
      o.value = String(n);
      o.textContent = n === 0 ? "全部" : String(n);
      capSel.appendChild(o);
    });
    capSel.value = String(listCap);
    capWrap.appendChild(capSel);
    fltBar.appendChild(capWrap);
    sec.appendChild(fltBar);
    visitPane.appendChild(sec);

    visitPane.appendChild(el("div", { class: "vac-v2-empty", id: "vac-v2-empty", text: "尚未匯入訪視對象。請於本頁匯入訪視對象 CSV 或 Excel（第一張工作表；Big5／UTF-8）。個資只留在本機。" }));

    var colHead = el("div", { class: "vac-v2-visit-cols" });
    ["責任區", "服務網", "生日月", "姓名", "地址", "排訪"].forEach(function (t) {
      colHead.appendChild(el("span", { text: t }));
    });
    visitPane.appendChild(colHead);
    visitPane.appendChild(el("div", { class: "vac-v2-vlist vac-v2-visit-list", id: "vac-v2-vlist", role: "list" }));

    var qHead = el("div", { class: "vac-v2-qhead" });
    qHead.appendChild(el("strong", { id: "vac-v2-q-title", text: "排訪清單" }));
    var qBtns = el("div", { class: "vac-v2-qhead-btns" });
    qBtns.appendChild(el("button", { type: "button", class: "vac-v2-btn", id: "vac-v2-done-toggle", text: "已訪清單" }));
    qBtns.appendChild(el("button", { type: "button", class: "vac-v2-btn", id: "vac-v2-q-toggle", text: "隱藏排訪清單" }));
    qHead.appendChild(qBtns);
    visitPane.appendChild(qHead);
    visitPane.appendChild(el("div", { id: "vac-v2-qlist", class: "vac-v2-qlist", role: "list" }));
    visitPane.appendChild(el("div", { id: "vac-v2-dlist", class: "vac-v2-qlist vac-v2-dlist", role: "list", hidden: "hidden" }));

    editor.appendChild(tabs);
    editor.appendChild(visitPane);
    editor.appendChild(villageWrap);
  }

  function bindUi() {
    if ($("vac-v2-tools-toggle")) {
      $("vac-v2-tools-toggle").addEventListener("click", function (ev) {
        ev.preventDefault();
        ev.stopPropagation();
        setToolsCollapsed(!toolsCollapsed);
      });
    }
    function collapseToolsIfPhoneSheet() {
      if (window.innerWidth >= 700) return;
      var body = document.body;
      if (!body) return;
      var sheetOpen = !body.classList.contains("vac-right-collapsed") || !body.classList.contains("vac-left-collapsed");
      if (sheetOpen && !toolsCollapsed) setToolsCollapsed(true);
    }
    ["vac-right-tab", "vac-left-tab"].forEach(function (id) {
      var t = $(id);
      if (t) t.addEventListener("click", function () { setTimeout(collapseToolsIfPhoneSheet, 0); });
    });
    var foldBtn = $("vac-v2-fold-import");
    if (foldBtn) {
      foldBtn.addEventListener("click", function () {
        var vets = $("vac-v2-veterans");
        if (!vets) return;
        var on = !vets.classList.contains("is-folded");
        vets.classList.toggle("is-folded", on);
        vets.dataset.userFold = on ? "1" : "0";
        foldBtn.textContent = on ? "顯示匯入工具" : "收合匯入工具";
        try { localStorage.setItem("vac-v2-import-folded", on ? "1" : "0"); } catch (e) {}
      });
    }
    window.addEventListener("resize", function () { syncImportFold(); });
    $("vac-v2-locate").addEventListener("click", function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      toggleLocateMenu();
    });
    var locMenu = $("vac-v2-locate-menu");
    if (locMenu) {
      locMenu.addEventListener("click", function (ev) {
        ev.stopPropagation();
        var btn = ev.target && ev.target.closest ? ev.target.closest("button[data-act]") : null;
        if (!btn) return;
        var act = btn.getAttribute("data-act");
        if (act === "addr-ok") {
          confirmAddrStart();
          return;
        }
        closeLocateMenu();
        if (act === "gps") doLocateGps();
        else if (act === "pin") startCustomLocate();
        else if (act === "clear") clearMyPosition();
      });
    }
    document.addEventListener("click", function (ev) {
      var wrap = $("vac-v2-locate-wrap");
      if (wrap && ev.target && wrap.contains(ev.target)) return;
      closeLocateMenu();
    });
    window.addEventListener("resize", function () { if (locMenuOpen) placeLocateMenu(); });
    window.addEventListener("scroll", function () { if (locMenuOpen) placeLocateMenu(); }, true);
    if ($("vac-v2-addr-input")) {
      $("vac-v2-addr-input").addEventListener("keydown", function (ev) {
        var box = $("vac-v2-addr-suggest");
        var open = box && !box.hidden && box.querySelector(".vac-v2-addr-suggest-item");
        if (ev.key === "ArrowDown" || ev.key === "ArrowUp") {
          if (!open) return;
          ev.preventDefault();
          moveAddrSuggest(ev.key === "ArrowDown" ? 1 : -1);
          return;
        }
        if (ev.key === "Enter") {
          ev.preventDefault();
          ev.stopPropagation();
          if (open && suggestActive >= 0) {
            var item = box.querySelectorAll(".vac-v2-addr-suggest-item")[suggestActive];
            if (item) { pickAddrSuggest(item.textContent); return; }
          }
          confirmAddrStart();
          return;
        }
        if (ev.key === "Escape") {
          ev.preventDefault();
          if (open) hideAddrSuggest();
          else closeLocateMenu();
        }
      });
      $("vac-v2-addr-input").addEventListener("input", function () {
        if (suggestTimer) clearTimeout(suggestTimer);
        suggestTimer = setTimeout(refreshAddrSuggest, 80);
      });
      $("vac-v2-addr-input").addEventListener("click", function (ev) { ev.stopPropagation(); });
    }
    $("vac-v2-measure").addEventListener("click", function (ev) { ev.preventDefault(); ev.stopPropagation(); toggleMeasure(); });
    $("vac-v2-undo").addEventListener("click", function (ev) { ev.preventDefault(); ev.stopPropagation(); undoVertex(); });
    $("vac-v2-clear-path").addEventListener("click", function (ev) { ev.preventDefault(); ev.stopPropagation(); clearPath(); });
    $("vac-v2-done").addEventListener("click", function (ev) { ev.preventDefault(); ev.stopPropagation(); finishMeasure(); });
    $("vac-v2-wipe").addEventListener("click", openWipeModal);
    $("vac-v2-wipe-cancel").addEventListener("click", function () { $("vac-v2-wipe-modal").classList.remove("is-on"); });
    $("vac-v2-wipe-ok").addEventListener("click", confirmWipePii);
    $("vac-v2-speed").addEventListener("change", onSpeed);
    $("vac-v2-speed").addEventListener("input", onSpeed);
    $("vac-v2-imp-vet").addEventListener("click", function () { $("vac-v2-file-vet").click(); });
    if ($("vac-v2-init-visit")) $("vac-v2-init-visit").addEventListener("click", initVisitWorkspace);
    $("vac-v2-imp-door").addEventListener("click", function () {
      pendingDoorMode = "replace";
      $("vac-v2-file-door").click();
    });
    $("vac-v2-load-doorpack").addEventListener("click", function () { loadDoorPackFlow(); });
    if ($("vac-v2-door-pass")) $("vac-v2-door-pass").addEventListener("click", function () {
      doorApi("status").then(function (st) {
        if (!st || !st._parsed) {
          doorNotice("這個網址還沒接上門牌後端", "請改用對話裡的地圖預覽設定／變更密碼。kcv 發佈含後端後，密碼可與預覽同步。");
          return;
        }
        if (!st.configured) openDoorPassModal("setup");
        else openDoorPassModal("change-auth");
      }).catch(function () {
        doorNotice("密碼服務未連上", "請重新整理後再由管理者設定密碼。");
      });
    });
    if ($("vac-v2-pass-cancel")) $("vac-v2-pass-cancel").addEventListener("click", function () {
      doorPassAfter = null;
      closeDoorPassModal();
    });
    if ($("vac-v2-pass-ok")) $("vac-v2-pass-ok").addEventListener("click", submitDoorPassModal);
    ["vac-v2-pass-old", "vac-v2-pass-new", "vac-v2-pass-cf", "vac-v2-pass-staff"].forEach(function (id) {
      var n = $(id);
      if (n) n.addEventListener("keydown", function (ev) {
        if (ev.key === "Enter") { ev.preventDefault(); submitDoorPassModal(); }
      });
    });
    if ($("vac-v2-notice-ok")) $("vac-v2-notice-ok").addEventListener("click", function () {
      var m = $("vac-v2-notice-modal");
      if (m) m.classList.remove("is-on");
    });
    $("vac-v2-file-vet").addEventListener("change", onVeteranFile);
    $("vac-v2-file-door").addEventListener("change", onDoorFile);
    $("vac-v2-file-doorpack").addEventListener("change", onDoorPackFiles);
    $("vac-v2-mask").addEventListener("change", function () {
      maskName = $("vac-v2-mask").checked;
      try { localStorage.setItem("vac-v2-mask-name", maskName ? "1" : "0"); } catch (e) {}
      renderVeteranList();
      renderVisitQueue();
      refreshMarkers();
    });
    $("vac-v2-search").addEventListener("input", scheduleFilterRefresh);
    function onListFilterChange() {
      listZoneFilter = ($("vac-v2-flt-zone") && $("vac-v2-flt-zone").value) || "";
      listNetFilter = ($("vac-v2-flt-net") && $("vac-v2-flt-net").value) || "";
      listBdayFilter = ($("vac-v2-flt-bday") && $("vac-v2-flt-bday").value) || "";
      birthdayMonth = listBdayFilter;
      persistListFilters();
      scheduleFilterRefresh();
    }
    ["vac-v2-flt-zone", "vac-v2-flt-net", "vac-v2-flt-bday"].forEach(function (id) {
      if ($(id)) $(id).addEventListener("change", onListFilterChange);
    });
    if ($("vac-v2-list-cap")) {
      try {
        var savedCap = localStorage.getItem("vac-v2-list-cap");
        if (savedCap != null && LIST_CAP_CHOICES.indexOf(Number(savedCap)) >= 0) {
          listCap = Number(savedCap);
        }
      } catch (e) {}
      $("vac-v2-list-cap").value = String(listCap);
      $("vac-v2-list-cap").addEventListener("change", function () {
        listCap = Number($("vac-v2-list-cap").value);
        if (LIST_CAP_CHOICES.indexOf(listCap) < 0) listCap = 250;
        try { localStorage.setItem("vac-v2-list-cap", String(listCap)); } catch (e) {}
        renderVeteranList();
      });
    }
    if ($("vac-v2-done-toggle")) {
      $("vac-v2-done-toggle").addEventListener("click", function () {
        showVisitPanel = true;
        showDonePanel = !showDonePanel;
        applyVisitPanelVis();
        if (showDonePanel) renderDoneList();
        else renderVisitQueue();
      });
    }
    if ($("vac-v2-optimize")) $("vac-v2-optimize").addEventListener("click", optimizeVisitOrder);
    if ($("vac-v2-export-visit")) $("vac-v2-export-visit").addEventListener("click", exportVisitCsv);
    if ($("vac-v2-dl-sample")) $("vac-v2-dl-sample").addEventListener("click", downloadSampleCsv);
    if ($("vac-v2-export-fail")) $("vac-v2-export-fail").addEventListener("click", exportFailCsv);
    /* 今日進度條已移除 */
    if ($("vac-v2-legend-close")) $("vac-v2-legend-close").addEventListener("click", function () {
      var lg = $("vac-v2-legend");
      if (lg) lg.style.display = "none";
    });
    if ($("vac-v2-tab-visit")) $("vac-v2-tab-visit").addEventListener("click", function () { setRightTab("visit"); });
    if ($("vac-v2-tab-village")) $("vac-v2-tab-village").addEventListener("click", function () { setRightTab("village"); });
    if ($("vac-v2-q-toggle")) $("vac-v2-q-toggle").addEventListener("click", toggleVisitPanel);
    if ($("vac-v2-start-first")) {
      $("vac-v2-start-first").addEventListener("change", function () {
        routeStartMode = $("vac-v2-start-first").checked ? "first" : "mypos";
        try { localStorage.setItem(LS_ROUTE_START, routeStartMode); } catch (e) {}
        updateOptimizeEnabled();
        scheduleVisitRoute();
      });
    }
    document.addEventListener("change", function (ev) {
      var t = ev.target;
      if (!t) return;
      if (t.classList && t.classList.contains("vac-zone-cb") && !syncingZoneNets) {
        applyZoneNetLink(t);
      }
      if (t.classList && (t.classList.contains("vac-zone-cb") || t.classList.contains("vac-net-cb"))) {
        cachedFilter = null;
        scheduleFilterRefresh();
      }
    });
    ["vac-zone-select-all", "vac-zone-clear", "vac-net-select-all", "vac-net-clear"].forEach(function (id) {
      var b = $(id);
      if (b) b.addEventListener("click", function () {
        if (id === "vac-zone-select-all") {
          document.querySelectorAll(".vac-zone-cb").forEach(function (cb) {
            if (cb.checked) applyZoneNetLink(cb);
          });
        }
        setTimeout(scheduleFilterRefresh, 0);
      });
    });
    if (window.MutationObserver) {
      var mo = new MutationObserver(function () { scheduleFilterRefresh(); });
      ["vac-zone-list", "vac-net-list"].forEach(function (id) {
        var node = $(id);
        if (node) mo.observe(node, { childList: true, subtree: true });
      });
    }
    var vetLayer = $("vac-layer-vet");
    if (vetLayer) vetLayer.addEventListener("change", function () {
      var on = vetLayer.checked;
      requestAnimationFrame(function () {
        if (!cluster || !map) return;
        if (on) {
          if (!map.hasLayer(cluster)) cluster.addTo(map);
        } else if (map.hasLayer(cluster)) {
          map.removeLayer(cluster);
        }
      });
    });
    $("vac-v2-map-cancel").addEventListener("click", function () {
      $("vac-v2-mapmodal").classList.remove("is-on");
      pendingDoorText = null;
    });
    $("vac-v2-map-ok").addEventListener("click", confirmDoorImport);
    document.addEventListener("keydown", function (ev) {
      if (ev.key === "Escape" || ev.keyCode === 27) {
        if (customLocateMode) {
          cancelCustomLocate(false);
          ev.stopPropagation();
        } else if (measuring) {
          setMeasuring(false);
          ev.stopPropagation();
        }
        closeLocateMenu();
        var md = $("vac-v2-mapmodal");
        if (md) md.classList.remove("is-on");
        var wm = $("vac-v2-wipe-modal");
        if (wm) wm.classList.remove("is-on");
      }
    }, true);
  }

  function findMap() {
    var node = document.querySelector(".folium-map");
    if (node && node.id && window[node.id] && window[node.id] instanceof L.Map) return window[node.id];
    for (var k in window) {
      try { if (window[k] instanceof L.Map) return window[k]; } catch (e) {}
    }
    return null;
  }

  function ensureCluster() {
    if (cluster) return cluster;
    if (L.markerClusterGroup) {
      cluster = L.markerClusterGroup({
        showCoverageOnHover: false,
        maxClusterRadius: 48,
        disableClusteringAtZoom: 17,
        spiderfyOnMaxZoom: true,
        iconCreateFunction: function (c) {
          var n = c.getChildCount();
          var size = n < 10 ? 34 : n < 40 ? 42 : 50;
          return L.divIcon({
            html: '<div class="vac-v2-cluster"><span>' + n + "</span></div>",
            className: "vac-v2-cluster-icon",
            iconSize: [size, size]
          });
        }
      });
    } else {
      cluster = L.layerGroup();
    }
    cluster.addTo(map);
    return cluster;
  }

  function watchTiles() {
    function attachTileHint(ly) {
      if (!(ly instanceof L.TileLayer)) return;
      ly.on("tileerror", function () {
        if (tileHintShown) return;
        tileHintShown = true;
        toast("底圖來源已更換／請檢查網路。無網時村里界、榮民與測繪仍可用。", "warn", 6000);
      });
    }
    map.eachLayer(attachTileHint);
    map.on("layeradd", function (e) { attachTileHint(e.layer); });
    window.addEventListener("offline", function () {
      toast("目前無網路：村里界、榮民與測繪仍可用，底圖可能空白。", "warn", 5000);
    });
  }

  function setLocateBtnLabel(txt) {
    var btn = $("vac-v2-locate");
    if (!btn) return;
    btn.disabled = false;
    btn.textContent = txt || "我的位置 ▾";
  }

  function placeLocateMenu() {
    var menu = $("vac-v2-locate-menu");
    var btn = $("vac-v2-locate");
    if (!menu || !btn || !locMenuOpen) return;
    var r = btn.getBoundingClientRect();
    var w = menu.offsetWidth || 160;
    var left = r.left;
    if (left + w > window.innerWidth - 8) left = Math.max(8, window.innerWidth - w - 8);
    menu.style.position = "fixed";
    menu.style.top = Math.round(r.bottom + 4) + "px";
    menu.style.left = Math.round(left) + "px";
    menu.style.right = "auto";
  }

  function toggleLocateMenu() {
    locMenuOpen = !locMenuOpen;
    var menu = $("vac-v2-locate-menu");
    var btn = $("vac-v2-locate");
    if (menu) menu.classList.toggle("is-on", locMenuOpen);
    if (btn) btn.setAttribute("aria-expanded", locMenuOpen ? "true" : "false");
    if (locMenuOpen) {
      setAddrErr("");
      var inp = $("vac-v2-addr-input");
      var saved = loadCustomPos();
      if (inp && !inp.value && saved && saved.addr) inp.value = saved.addr;
      placeLocateMenu();
    }
  }

  function closeLocateMenu() {
    locMenuOpen = false;
    var menu = $("vac-v2-locate-menu");
    var btn = $("vac-v2-locate");
    if (menu) menu.classList.remove("is-on");
    if (btn) btn.setAttribute("aria-expanded", "false");
    hideAddrSuggest();
  }

  function clearMyPositionLayers() {
    if (gpsMarker) { map.removeLayer(gpsMarker); gpsMarker = null; }
    if (gpsCircle) { map.removeLayer(gpsCircle); gpsCircle = null; }
  }

  function placeMyPosition(lat, lng, kind, acc, addrLabel) {
    clearMyPositionLayers();
    myPosKind = kind;
    gpsMarker = L.circleMarker([lat, lng], {
      radius: 8, color: "#fff", weight: 2, fillColor: GPS_COLOR, fillOpacity: 1
    }).addTo(map);
    var pop = document.createElement("div");
    var t = document.createElement("div");
    t.style.fontWeight = "800";
    t.textContent = kind === "addr" ? "出發地（地址）" : (kind === "custom" ? "我的位置（自訂）" : "目前位置");
    pop.appendChild(t);
    if (kind === "addr" || kind === "custom") {
      var tag = document.createElement("div");
      tag.style.fontSize = "11px";
      tag.style.color = "#1565c0";
      tag.style.marginTop = "2px";
      tag.textContent = kind === "addr" ? (addrLabel || "地址") : "自訂";
      pop.appendChild(tag);
    }
    gpsMarker.bindPopup(pop);
    if (kind === "gps" && acc > 0) {
      gpsCircle = L.circle([lat, lng], {
        radius: acc, color: GPS_COLOR, weight: 1, fillColor: GPS_COLOR, fillOpacity: 0.12, interactive: false
      }).addTo(map);
    }
    map.setView([lat, lng], Math.max(map.getZoom(), 16));
    scheduleVisitRoute();
    updateOptimizeEnabled();
  }

  function saveCustomPos(lat, lng, addr) {
    try { localStorage.setItem(LS_CUSTOM, JSON.stringify({ lat: lat, lng: lng, t: Date.now(), addr: addr ? String(addr) : "" })); } catch (e) {}
  }

  function loadCustomPos() {
    try {
      var raw = localStorage.getItem(LS_CUSTOM);
      if (!raw) return null;
      var o = JSON.parse(raw);
      if (o && typeof o.lat === "number" && typeof o.lng === "number") return o;
    } catch (e) {}
    return null;
  }

  function clearCustomPosStorage() {
    try { localStorage.removeItem(LS_CUSTOM); } catch (e) {}
  }

  function clearMyPosition() {
    cancelCustomLocate(true);
    clearMyPositionLayers();
    myPosKind = null;
    clearCustomPosStorage();
    toast("已清除我的位置", "ok", 2200);
      scheduleVisitRoute();
    updateOptimizeEnabled();
  }

  function cancelCustomLocate(silent) {
    if (!customLocateMode) return;
    customLocateMode = false;
    if (map) map.getContainer().classList.remove("vac-v2-custom-locate");
    var hud = $("vac-v2-hud");
    if (hud && !measuring) {
      hud.classList.remove("is-on");
      if (!measureVerts.length) hud.textContent = "";
    }
    if (!silent) toast("已取消點地圖設定", "info", 1800);
  }

  function startCustomLocate() {
    if (measuring) setMeasuring(false);
    customLocateMode = true;
    map.getContainer().classList.add("vac-v2-custom-locate");
    var hud = $("vac-v2-hud");
    if (hud) {
      hud.textContent = "點地圖設定我的位置；Esc 取消";
      hud.classList.add("is-on");
    }
    toast("點一下地圖設定我的位置", "ok", 2500);
  }

  function finishCustomLocate(latlng) {
    customLocateMode = false;
    map.getContainer().classList.remove("vac-v2-custom-locate");
    placeMyPosition(latlng.lat, latlng.lng, "custom", 0);
    saveCustomPos(latlng.lat, latlng.lng, "");
    var hud = $("vac-v2-hud");
    if (hud && !measuring) hud.classList.remove("is-on");
    toast("已設定自訂位置", "ok", 2200);
  }

  function setAddrErr(msg) {
    var err = $("vac-v2-addr-err");
    if (err) err.textContent = msg || "";
  }

  function roadStemFromKey(key) {
    var s = String(key || "");
    var m = s.match(/高雄市[\u4e00-\u9fff]{1,4}[區鄉鎮市]([^\d]+?(?:路|街|大道|道|巷))/);
    if (!m) m = s.match(/([^\d]+?(?:路|街|大道|道|巷))/);
    if (!m) return "";
    return String(m[1] || "").replace(/^.*[區鄉鎮市]/, "");
  }

  function resetDoorSuggest() {
    suggestByRoad = Object.create(null);
    suggestRoadNames = [];
    suggestIndexGen++;
  }

  function indexDoorKey(key) {
    var road = roadStemFromKey(key);
    if (!road) return;
    var arr = suggestByRoad[road];
    if (!arr) {
      suggestByRoad[road] = [key];
      suggestRoadNames.push(road);
    } else if (arr[arr.length - 1] !== key && arr.indexOf(key) < 0) {
      arr.push(key);
    }
  }

  function scheduleSuggestRebuild() {
    var keys = [];
    for (var k in doorExact) {
      if (Object.prototype.hasOwnProperty.call(doorExact, k)) keys.push(k);
    }
    resetDoorSuggest();
    var gen = suggestIndexGen;
    var i = 0;
    function step() {
      if (gen !== suggestIndexGen) return;
      var end = Math.min(i + 20000, keys.length);
      for (; i < end; i++) indexDoorKey(keys[i]);
      if (i < keys.length) setTimeout(step, 16);
    }
    if (keys.length) setTimeout(step, 0);
  }

  function doorRank(key, road) {
    var i = key.indexOf(road);
    var tail = i >= 0 ? key.slice(i + road.length) : key;
    var m = tail.match(/^(\d+)/);
    var n = m ? Number(m[1]) : 999999;
    var z = tail.match(/之(\d+)/);
    return n * 1000 + (z ? Number(z[1]) : 0);
  }

  function hideAddrSuggest() {
    suggestActive = -1;
    var box = $("vac-v2-addr-suggest");
    var inp = $("vac-v2-addr-input");
    if (box) {
      box.hidden = true;
      box.innerHTML = "";
    }
    if (inp) inp.setAttribute("aria-expanded", "false");
  }

  function moveAddrSuggest(dir) {
    var box = $("vac-v2-addr-suggest");
    if (!box) return;
    var items = box.querySelectorAll(".vac-v2-addr-suggest-item");
    if (!items.length) return;
    suggestActive = (suggestActive + dir + items.length) % items.length;
    for (var i = 0; i < items.length; i++) items[i].classList.toggle("is-on", i === suggestActive);
    if (items[suggestActive].scrollIntoView) items[suggestActive].scrollIntoView({ block: "nearest" });
  }

  function pickAddrSuggest(text) {
    var inp = $("vac-v2-addr-input");
    if (inp) inp.value = text;
    hideAddrSuggest();
    confirmAddrStart();
  }

  function suggestDoors(raw) {
    var q = normalizeAddr(raw).replace(/^高雄市/, "");
    q = q.replace(/^[\u4e00-\u9fff]{1,4}[區鄉鎮]/, "");
    if (q.length < 2) return [];
    var roads = [];
    for (var i = 0; i < suggestRoadNames.length; i++) {
      var road = suggestRoadNames[i];
      if (road.indexOf(q) === 0 || q.indexOf(road) === 0) roads.push(road);
    }
    roads.sort(function (a, b) {
      var as = a.indexOf(q) === 0 ? 0 : 1;
      var bs = b.indexOf(q) === 0 ? 0 : 1;
      if (as !== bs) return as - bs;
      if (a.length !== b.length) return a.length - b.length;
      return a < b ? -1 : a > b ? 1 : 0;
    });
    if (roads.length > 8) roads = roads.slice(0, 8);
    var hits = [];
    var perRoad = roads.length > 1 ? 2 : 8;
    for (var r = 0; r < roads.length && hits.length < 8; r++) {
      var name = roads[r];
      var rest = q.indexOf(name) === 0 ? q.slice(name.length) : "";
      var list = suggestByRoad[name] || [];
      var local = [];
      for (var j = 0; j < list.length; j++) {
        var key = list[j];
        var at = key.indexOf(name);
        var tail = at >= 0 ? key.slice(at + name.length) : "";
        if (rest && tail.indexOf(rest) !== 0) continue;
        var rank = doorRank(key, name);
        if (local.length < perRoad) {
          local.push({ key: key, rank: rank });
          if (local.length === perRoad) local.sort(function (a, b) { return a.rank - b.rank; });
        } else if (rank < local[local.length - 1].rank) {
          local[local.length - 1] = { key: key, rank: rank };
          local.sort(function (a, b) { return a.rank - b.rank; });
        }
      }
      local.sort(function (a, b) { return a.rank - b.rank; });
      for (var t = 0; t < local.length && hits.length < 8; t++) hits.push(local[t].key);
    }
    return hits;
  }

  function refreshAddrSuggest() {
    suggestTimer = 0;
    var inp = $("vac-v2-addr-input");
    var box = $("vac-v2-addr-suggest");
    if (!inp || !box) return;
    var raw = String(inp.value || "").trim();
    if (raw.length < 2) { hideAddrSuggest(); return; }
    if (!doorReady) {
      renderAddrSuggest([], "請先載入內建門牌，才能列出地址");
      return;
    }
    if (!suggestRoadNames.length) {
      renderAddrSuggest([], "門牌建議整理中…");
      return;
    }
    renderAddrSuggest(suggestDoors(raw), "");
  }

  function renderAddrSuggest(items, note) {
    var box = $("vac-v2-addr-suggest");
    var inp = $("vac-v2-addr-input");
    if (!box) return;
    box.innerHTML = "";
    suggestActive = -1;
    if (!items.length && !note) { hideAddrSuggest(); return; }
    box.hidden = false;
    if (inp) inp.setAttribute("aria-expanded", "true");
    if (note && !items.length) {
      var p = document.createElement("div");
      p.className = "vac-v2-addr-suggest-note";
      p.textContent = note;
      box.appendChild(p);
      return;
    }
    items.forEach(function (text) {
      var b = document.createElement("button");
      b.type = "button";
      b.className = "vac-v2-addr-suggest-item";
      b.setAttribute("role", "option");
      b.textContent = text;
      b.addEventListener("mousedown", function (ev) { ev.preventDefault(); });
      b.addEventListener("click", function (ev) {
        ev.preventDefault();
        ev.stopPropagation();
        pickAddrSuggest(text);
      });
      box.appendChild(b);
    });
  }

  function confirmAddrStart() {
    var inp = $("vac-v2-addr-input");
    var raw = inp ? String(inp.value || "").trim() : "";
    if (!raw) {
      setAddrErr("請輸入地址（行政區＋路或街＋號）");
      return;
    }
    if (!doorReady) {
      setAddrErr("請先載入內建門牌，才能用地址當出發地。");
      return;
    }
    var hit = matchOne(raw);
    if (!hit || hit.lat == null || hit.lng == null) {
      var alts = suggestDoors(raw);
      if (alts.length === 1) {
        raw = alts[0];
        if (inp) inp.value = raw;
        hit = matchOne(raw);
      } else if (alts.length > 1) {
        renderAddrSuggest(alts, "");
        setAddrErr("有多筆相符，請點選其中一筆");
        return;
      }
    }
    if (!hit || hit.lat == null || hit.lng == null) {
      var msg = (hit && hit.reason) || "對不到門牌";
      if (hit && hit.failKind === "no-pack") msg = "請先載入內建門牌，才能用地址當出發地。";
      else if (!extractTownLi(raw)) msg = "門牌索引沒有這筆。請改打行政區，或從建議清單點選";
      setAddrErr(msg);
      return;
    }
    setAddrErr("");
    closeLocateMenu();
    placeMyPosition(hit.lat, hit.lng, "addr", 0, raw);
    saveCustomPos(hit.lat, hit.lng, raw);
    toast(hit.status === "low" ? "已設出發地（低信心對位）" : "已設出發地", hit.status === "low" ? "warn" : "ok", 2800);
  }

  function doLocateGps() {
    if (customLocateMode) cancelCustomLocate(true);
    if (measuring) setMeasuring(false);
    var btn = $("vac-v2-locate");
    if (!navigator.geolocation) {
      toast("此瀏覽器不支援定位。", "error");
      return;
    }
    if (location.protocol === "file:") {
      toast("file:// 可能無法定位。請用本機靜態伺服（npx serve 或 python -m http.server）後再試，並允許位置權限。", "warn", 7000);
    }
    btn.disabled = true;
    btn.textContent = "";
    var spin = document.createElement("span");
    spin.className = "vac-v2-spin";
    btn.appendChild(spin);
    btn.appendChild(document.createTextNode("定位中…"));
    navigator.geolocation.getCurrentPosition(function (pos) {
      setLocateBtnLabel("我的位置 ▾");
      clearCustomPosStorage();
      placeMyPosition(pos.coords.latitude, pos.coords.longitude, "gps", pos.coords.accuracy || 0);
      toast("已標示目前位置", "ok", 2200);
    }, function (err) {
      setLocateBtnLabel("我的位置 ▾");
      var code = err && err.code;
      var msg;
      if (code === 1) msg = "無法定位，請允許位置權限。若以 file:// 開啟，請改用本機靜態伺服（如 npx serve）。";
      else if (code === 3) msg = "定位逾時，請移至空曠處重試。";
      else if (code === 2) msg = "無法取得位置（位置不可用）。請確認裝置 GPS 已開啟。";
      else msg = "無法定位。" + (location.protocol === "file:" ? " file:// 請改用本機靜態伺服（如 npx serve）。" : " 請允許位置權限後重試。");
      toast(msg, "error", 7000);
    }, { enableHighAccuracy: true, timeout: GEO_TIMEOUT, maximumAge: 0 });
  }

  function pathKm() {
    if (routeSegs.length) {
      var km = 0;
      for (var i = 0; i < routeSegs.length; i++) km += routeSegs[i].km || 0;
      return km;
    }
    var h = 0;
    for (var j = 1; j < measureVerts.length; j++) h += haversineKm(measureVerts[j - 1], measureVerts[j]);
    return h;
  }

  function routeModeSummary() {
    if (routeLoading) return "loading";
    if (!routeSegs.length) return "none";
    var st = 0, rt = 0;
    for (var i = 0; i < routeSegs.length; i++) {
      if (routeSegs[i].mode === "straight") st++;
      else rt++;
    }
    if (st && rt) return "partial";
    if (st) return "straight";
    return "route";
  }

  function formatDist(km) {
    if (km >= 1) return km.toFixed(2) + " km";
    return Math.round(km * 1000) + " m";
  }

  function etaMinutes(km) {
    var sp = speedKmh;
    if (!(sp >= 10 && sp <= 25)) sp = 15;
    return Math.round((km / sp) * 60);
  }

  function updateMetrics() {
    var elM = $("vac-v2-metrics");
    var hud = $("vac-v2-hud");
    var n = measureVerts.length;
    hud.classList.remove("is-warn");
    if (n < 2) {
      elM.textContent = n === 1 ? "已 1 點（再點加距離）" : "距離 —";
      hud.classList.remove("is-on");
      if (measuring) {
        hud.textContent = "測繪中：點一下加點，拖曳可移動地圖。Esc 或「完成」結束。";
        hud.classList.add("is-on");
      }
      return;
    }
    if (routeLoading) {
      elM.textContent = "路由計算中…";
      hud.textContent = "路由計算中…";
      hud.classList.add("is-on");
      return;
    }
    var km = pathKm();
    var mins = etaMinutes(km);
    var eta = (mins === 0 && km > 0) ? "不到 1 分" : ("約 " + mins + " 分");
    var mode = routeModeSummary();
    var prefix;
    if (mode === "route") prefix = "沿道路 · ";
    else if (mode === "partial") prefix = "部分路段為直線 · ";
    else if (mode === "straight") prefix = "直線（路由失敗／離線）· ";
    else prefix = "";
    var txt = prefix + formatDist(km) + " · " + eta + "（" + speedKmh + " km/h）";
    elM.textContent = txt;
    hud.textContent = (measuring ? "測繪中 · " : "") + txt + " · " + n + " 點";
    if (mode === "straight" || mode === "partial") hud.classList.add("is-warn");
    hud.classList.add("is-on");
  }

  function redrawMeasureLayers() {
    if (!measureLayer) measureLayer = L.layerGroup().addTo(map);
    measureLayer.clearLayers();
    if (measureVerts.length >= 2) {
      if (routeSegs.length) {
        for (var s = 0; s < routeSegs.length; s++) {
          var seg = routeSegs[s];
          var latlngs = (seg.coords || []).map(function (pt) { return [pt.lat, pt.lng]; });
          if (latlngs.length >= 2) {
            measureLayer.addLayer(L.polyline(latlngs, {
              color: MEASURE_COLOR, weight: 3, opacity: 0.95, interactive: false,
              dashArray: seg.mode === "straight" ? "6 6" : null
            }));
          }
        }
      } else {
        measureLayer.addLayer(L.polyline(measureVerts.map(function (pt) { return [pt.lat, pt.lng]; }), {
          color: MEASURE_COLOR, weight: 3, opacity: 0.55, interactive: false, dashArray: "4 6"
        }));
      }
    }
    measureVerts.forEach(function (pt, idx) {
      measureLayer.addLayer(L.circleMarker([pt.lat, pt.lng], {
        radius: idx === 0 || idx === measureVerts.length - 1 ? 6 : 4,
        color: "#fff", weight: 1.5, fillColor: MEASURE_COLOR, fillOpacity: 1, interactive: false
      }));
    });
  }

  function redrawMeasure() {
    redrawMeasureLayers();
    updateMetrics();
    scheduleRouteRecompute();
  }

  async function fetchOsrmSegment(a, b) {
    var url = OSRM_ENDPOINT + "/" + a.lng + "," + a.lat + ";" + b.lng + "," + b.lat +
      "?overview=full&geometries=geojson";
    var ctrl = typeof AbortController !== "undefined" ? new AbortController() : null;
    var timer = setTimeout(function () { if (ctrl) ctrl.abort(); }, OSRM_TIMEOUT_MS);
    try {
      var res = await fetch(url, ctrl ? { signal: ctrl.signal, mode: "cors" } : { mode: "cors" });
      clearTimeout(timer);
      if (!res.ok) throw new Error("http " + res.status);
      var data = await res.json();
      var route = data && data.routes && data.routes[0];
      if (!route || !route.geometry || !route.geometry.coordinates) throw new Error("no route");
      var coords = route.geometry.coordinates.map(function (c) {
        return { lat: c[1], lng: c[0] };
      });
      if (coords.length < 2) throw new Error("short");
      return { coords: coords, km: (route.distance || 0) / 1000, mode: "route" };
    } catch (e) {
      clearTimeout(timer);
      return { coords: [a, b], km: haversineKm(a, b), mode: "straight" };
    }
  }

  function scheduleRouteRecompute() {
    var gen = ++routeGen;
    if (measureVerts.length < 2) {
      routeSegs = [];
      routeLoading = false;
      redrawMeasureLayers();
      updateMetrics();
      return;
    }
    routeLoading = true;
    updateMetrics();
    redrawMeasureLayers();
    (async function () {
      var segs = [];
      var anyStraight = false;
      for (var i = 1; i < measureVerts.length; i++) {
        if (gen !== routeGen) return;
        var seg = await fetchOsrmSegment(measureVerts[i - 1], measureVerts[i]);
        if (seg.mode === "straight") anyStraight = true;
        segs.push(seg);
      }
      if (gen !== routeGen) return;
      routeSegs = segs;
      routeLoading = false;
      if (anyStraight) toast("無法連線路徑服務，已改直線測距", "warn", 4200);
      redrawMeasureLayers();
      updateMetrics();
    })();
  }

  function addVertex(latlng) {
    measureVerts.push({ lat: latlng.lat, lng: latlng.lng });
    redrawMeasure();
  }

  function undoVertex() {
    if (!measuring && !measureVerts.length) {
      setMeasuring(true);
      toast("已開啟測繪。請點地圖加點，再按「復原末點」。", "ok", 2800);
      return;
    }
    if (!measureVerts.length) {
      toast("目前沒有測繪點可復原。請先按「測繪」後點地圖加點。", "warn", 2800);
      return;
    }
    measureVerts.pop();
    redrawMeasure();
    toast(measureVerts.length ? "已復原末點（剩 " + measureVerts.length + " 點）" : "已復原，測繪點清空", "ok", 1600);
  }

  function clearPath() {
    routeGen++;
    var had = measureVerts.length > 0 || (routeSegs && routeSegs.length);
    measureVerts = [];
    routeSegs = [];
    routeLoading = false;
    redrawMeasureLayers();
    updateMetrics();
    if (!measuring) {
      var hud = $("vac-v2-hud");
      if (hud) hud.classList.remove("is-on");
    }
    if (!had) toast("目前沒有測繪路徑。請先按「測繪」後點地圖加點。", "warn", 2800);
    else toast("已清除測繪路徑", "ok", 1600);
  }

  function finishMeasure() {
    if (!measuring && !measureVerts.length) {
      toast("目前不在測繪模式。請先按「測繪」後點地圖加點。", "warn", 2800);
      return;
    }
    setMeasuring(false);
    toast(measureVerts.length ? "測繪完成（" + measureVerts.length + " 點）" : "已結束測繪", "ok", 2000);
  }

  function setMeasuring(on) {
    measuring = !!on;
    var btn = $("vac-v2-measure");
    if (btn) {
      btn.setAttribute("aria-pressed", measuring ? "true" : "false");
      btn.classList.toggle("is-on", measuring);
    }
    if (map && map.getContainer) map.getContainer().classList.toggle("vac-v2-measuring", measuring);
    updateMetrics();
    if (!measuring && measureVerts.length < 2) {
      var hud = $("vac-v2-hud");
      if (hud) hud.classList.remove("is-on");
    }
  }

  function toggleMeasure() {
    if (!measuring && customLocateMode) cancelCustomLocate(true);
    setMeasuring(!measuring);
    if (measuring) toast("測繪中：點一下地圖加點；按住拖曳可移動地圖。Esc 或「完成」結束。", "ok", 3200);
    else toast("已關閉測繪模式", "ok", 1600);
  }

  function onSpeed() {
    var v = Number($("vac-v2-speed").value);
    if (isNaN(v)) v = 15;
    if (v < 10) v = 10;
    if (v > 25) v = 25;
    speedKmh = v;
    $("vac-v2-speed").value = String(v);
    updateMetrics();
  }

  var measurePtr = null;
  var MEASURE_DRAG_PX = 8;

  function onMeasurePtrDown(ev) {
    if (!measuring && !customLocateMode) { measurePtr = null; return; }
    if (ev.button != null && ev.button !== 0) { measurePtr = null; return; }
    var t = ev.touches && ev.touches[0] ? ev.touches[0] : ev;
    measurePtr = { x: t.clientX, y: t.clientY };
  }

  function measurePtrMoved(ev) {
    if (!measurePtr) return false;
    var t = ev.changedTouches && ev.changedTouches[0] ? ev.changedTouches[0] : ev;
    var dx = t.clientX - measurePtr.x;
    var dy = t.clientY - measurePtr.y;
    return (dx * dx + dy * dy) > (MEASURE_DRAG_PX * MEASURE_DRAG_PX);
  }

  function onMapClickCapture(ev) {
    if (!measuring && !customLocateMode) return;
    if (ev.button != null && ev.button !== 0) return;
    if (ev.target && ev.target.closest && (
      ev.target.closest(".leaflet-control") ||
      ev.target.closest(".leaflet-popup") ||
      ev.target.closest(".vac-v2-toolbar") ||
      ev.target.closest(".vac-v2-locate-wrap")
    )) return;
    if (measurePtrMoved(ev)) return;
    if (map.dragging && typeof map.dragging.moved === "function" && map.dragging.moved()) return;
    var latlng = map.mouseEventToLatLng(ev);
    if (customLocateMode) {
      finishCustomLocate(latlng);
      ev.preventDefault();
      ev.stopPropagation();
      if (ev.stopImmediatePropagation) ev.stopImmediatePropagation();
      return;
    }
    addVertex(latlng);
    ev.preventDefault();
    ev.stopPropagation();
    if (ev.stopImmediatePropagation) ev.stopImmediatePropagation();
  }

  function chipLabel(st) {
    if (st === "ok") return { cls: "ok", text: "已定位" };
    if (st === "low") return { cls: "low", text: "低信心" };
    if (st === "fail") return { cls: "fail", text: "失敗" };
    return { cls: "pend", text: "未跑" };
  }

  function stats() {
    var a = 0, b = 0, c = 0, n = veterans.length;
    for (var i = 0; i < n; i++) {
      if (veterans[i].status === "ok") a++;
      else if (veterans[i].status === "low") b++;
      else if (veterans[i].status === "fail") c++;
    }
    return { a: a, b: b, c: c, n: n, pend: n - a - b - c };
  }


  function numKey(s) {
    var m = String(s == null ? "" : s).match(/(\d+)/);
    return m ? m[1] : String(s || "").trim();
  }

  function checkedKeySet(sel) {
    var set = Object.create(null);
    var n = 0, all = 0;
    document.querySelectorAll(sel).forEach(function (cb) {
      all++;
      if (cb.checked) {
        set[numKey(cb.value)] = true;
        set[String(cb.value || "").trim()] = true;
        n++;
      }
    });
    return { set: set, n: n, all: all };
  }

  function getFilterSnap() {
    if (cachedFilter) return cachedFilter;
    cachedFilter = {
      z: checkedKeySet(".vac-zone-cb"),
      n: checkedKeySet(".vac-net-cb"),
      q: (($("vac-v2-search") && $("vac-v2-search").value) || "").trim().toLowerCase(),
      bday: listBdayFilter || birthdayMonth,
      lz: listZoneFilter,
      ln: listNetFilter,
      st: listStatusFilter
    };
    return cachedFilter;
  }

  function zoneNetPass(v, snap) {
    snap = snap || getFilterSnap();
    var z = snap.z;
    var n = snap.n;
    if (z.all > 0) {
      if (z.n === 0) return false;
      if (z.n < z.all) {
        var zraw = String(v.zone || "").trim();
        var zk = zraw ? numKey(zraw) : "";
        var zok = !zraw
          ? !!(z.set["__unset__"] || z.set["未指定"])
          : !!(z.set[zk] || z.set[zraw] || z.set["第" + zk + "責任區"]);
        if (!zok) return false;
      }
    }
    if (n.all > 0) {
      if (n.n === 0) return false;
      if (n.n < n.all) {
        var nraw = String(v.net || "").trim();
        var nk = nraw ? numKey(nraw) : "";
        var nok = !nraw
          ? !!(n.set["__unset__"] || n.set["未指定"])
          : !!(n.set[nk] || n.set[nraw] || n.set["第" + nk + "服務網"]);
        if (!nok) return false;
      }
    }
    return true;
  }

  function parseBirthMonth(raw) {
    var s = String(raw == null ? "" : raw).trim();
    if (!s) return "";
    var m = s.match(/(\d{1,2})\s*月/);
    if (m) {
      var n = Number(m[1]);
      if (n >= 1 && n <= 12) return String(n);
    }
    var nums = s.match(/\d{1,2}/g);
    if (!nums) return "";
    for (var i = nums.length - 1; i >= 0; i--) {
      var n2 = Number(nums[i]);
      if (n2 >= 1 && n2 <= 12) return String(n2);
    }
    return "";
  }

  function veteranPassesFilter(v, q, snap) {
    snap = snap || getFilterSnap();
    if (!zoneNetPass(v, snap)) return false;
    if (snap.lz) {
      var zraw = String(v.zone || "").trim();
      var zk = zraw ? numKey(zraw) : "__unset__";
      if (snap.lz === "__unset__") {
        if (zraw) return false;
      } else if (zk !== snap.lz && zraw !== snap.lz) return false;
    }
    if (snap.ln) {
      var nraw = String(v.net || "").trim();
      var nk = nraw ? numKey(nraw) : "__unset__";
      if (snap.ln === "__unset__") {
        if (nraw) return false;
      } else if (nk !== snap.ln && nraw !== snap.ln) return false;
    }
    var bm = snap.bday != null ? snap.bday : (listBdayFilter || birthdayMonth);
    if (bm) {
      if (String(v.birthMonth || "") !== String(bm)) return false;
    }
    var st = snap.st != null ? snap.st : listStatusFilter;
    if (st && String(v.status || "") !== String(st)) return false;
    q = q != null ? q : snap.q;
    if (q) {
      var hay = (v.name + " " + v.address + " " + v.zone + " " + v.net + " " + (v.birthMonth || "")).toLowerCase();
      if (hay.indexOf(q) < 0) return false;
    }
    return true;
  }

  function scheduleFilterRefresh() {
    cachedFilter = null;
    if (listTimer) clearTimeout(listTimer);
    listTimer = setTimeout(function () {
      renderVeteranList();
    }, 50);
    if (markerTimer) clearTimeout(markerTimer);
    markerTimer = setTimeout(function () {
      refreshMarkers();
    }, 140);
  }

  function findVeteranById(id) {
    for (var i = 0; i < veterans.length; i++) {
      if (veterans[i].id === id) return veterans[i];
    }
    return null;
  }

  function visitIndexOf(id) {
    for (var i = 0; i < visitQueue.length; i++) {
      if (visitQueue[i].id === id) return i;
    }
    return -1;
  }

  function isQueued(id) { return visitIndexOf(id) >= 0; }

  function doneIndexOf(id) {
    for (var i = 0; i < visitedList.length; i++) {
      if (visitedList[i].id === id) return i;
    }
    return -1;
  }

  function isVisited(id) { return doneIndexOf(id) >= 0; }

  function visitSemantic(v) {
    if (!v) return "pending";
    if (isVisited(v.id)) return "done";
    if (isQueued(v.id)) return "queued";
    return "pending";
  }

  function persistVisitQueue() {
    try {
      localStorage.setItem(LS_VISIT_Q, JSON.stringify(visitQueue.map(function (x) {
        return { id: x.id };
      })));
      localStorage.setItem(LS_VISIT_DONE, JSON.stringify(visitedList));
    } catch (e) {}
  }

  function restoreVisitQueue() {
    try {
      var raw = localStorage.getItem(LS_VISIT_Q);
      if (raw) {
        var arr = JSON.parse(raw);
        if (Array.isArray(arr)) {
          var pending = [];
          var migrated = [];
          arr.forEach(function (x) {
            if (!x || x.id == null || !findVeteranById(x.id)) return;
            if (x.visited) migrated.push({ id: x.id, at: Date.now() });
            else pending.push({ id: x.id });
          });
          visitQueue = pending;
          if (migrated.length) visitedList = visitedList.concat(migrated);
        }
      }
    } catch (e) { visitQueue = []; }
    try {
      var rawD = localStorage.getItem(LS_VISIT_DONE);
      if (rawD) {
        var arrD = JSON.parse(rawD);
        if (Array.isArray(arrD)) {
          var seen = Object.create(null);
          visitedList.forEach(function (x) { if (x && x.id != null) seen[x.id] = true; });
          arrD.forEach(function (x) {
            if (!x || x.id == null || !findVeteranById(x.id) || seen[x.id]) return;
            seen[x.id] = true;
            visitedList.push({ id: x.id, at: x.at || Date.now() });
          });
        }
      }
    } catch (e) {}
    visitQueue = visitQueue.filter(function (x) { return doneIndexOf(x.id) < 0; });
  }

  function setRightTab(which) {
    rightTab = which === "village" ? "village" : "visit";
    var tv = $("vac-v2-tab-visit");
    var tg = $("vac-v2-tab-village");
    var pane = $("vac-v2-visit-pane");
    var wrap = $("vac-v2-village-wrap");
    if (tv) {
      tv.classList.toggle("is-on", rightTab === "visit");
      tv.setAttribute("aria-selected", rightTab === "visit" ? "true" : "false");
    }
    if (tg) {
      tg.classList.toggle("is-on", rightTab === "village");
      tg.setAttribute("aria-selected", rightTab === "village" ? "true" : "false");
    }
    if (pane) pane.hidden = rightTab !== "visit";
    if (wrap) wrap.hidden = rightTab !== "village";
  }

  function applyVisitPanelVis() {
    var ql = $("vac-v2-qlist");
    var dl = $("vac-v2-dlist");
    var btn = $("vac-v2-q-toggle");
    var title = $("vac-v2-q-title");
    var wrap = $("vac-v2-qwrap");
    if (!showVisitPanel) {
      if (ql) ql.style.display = "none";
      if (dl) { dl.style.display = "none"; dl.hidden = true; }
    } else if (showDonePanel) {
      if (ql) ql.style.display = "none";
      if (dl) { dl.style.display = ""; dl.hidden = false; }
    } else {
      if (ql) ql.style.display = "";
      if (dl) { dl.style.display = "none"; dl.hidden = true; }
    }
    if (wrap) wrap.hidden = !showVisitPanel;
    if (btn) btn.textContent = showVisitPanel ? "隱藏清單" : "顯示清單";
    if (title) title.textContent = showDonePanel ? "已訪清單" : "排訪清單";
    var db = $("vac-v2-done-toggle");
    if (db) db.classList.toggle("is-on", showDonePanel);
  }

  function applyDonePanelVis() {
    applyVisitPanelVis();
  }

  function ensureVisitQueueVisible() {
    setRightTab("visit");
    showVisitPanel = true;
    try { localStorage.setItem(LS_VISIT_PANEL, "1"); } catch (e) {}
    applyVisitPanelVis();
    var ql = $("vac-v2-qlist");
    if (ql && ql.scrollIntoView) {
      try { ql.scrollIntoView({ block: "nearest", behavior: "smooth" }); } catch (e) { ql.scrollIntoView(); }
    }
  }

  function setToolsCollapsed(on) {
    toolsCollapsed = !!on;
    var bar = $("vac-v2-toolbar");
    var btn = $("vac-v2-tools-toggle");
    if (bar) bar.classList.toggle("is-collapsed", toolsCollapsed);
    if (btn) {
      btn.textContent = toolsCollapsed ? "工具" : "收合工具";
      btn.setAttribute("aria-expanded", toolsCollapsed ? "false" : "true");
      btn.setAttribute("aria-label", toolsCollapsed ? "展開工具列" : "收合工具列");
    }
    try { localStorage.setItem(LS_TOOLS, toolsCollapsed ? "1" : "0"); } catch (e) {}
  }

  function toggleVisitPanel() {
    showVisitPanel = !showVisitPanel;
    try { localStorage.setItem(LS_VISIT_PANEL, showVisitPanel ? "1" : "0"); } catch (e) {}
    applyVisitPanelVis();
  }

  function getMyLatLng() {
    if (gpsMarker && gpsMarker.getLatLng) {
      var ll = gpsMarker.getLatLng();
      return { lat: ll.lat, lng: ll.lng };
    }
    return null;
  }

  function getRouteStart() {
    var me = getMyLatLng();
    if (me) return { pt: me, label: "我的位置", kind: "mypos" };
    if (routeStartMode === "first") {
      for (var i = 0; i < visitQueue.length; i++) {
        var v = findVeteranById(visitQueue[i].id);
        if (v && v.lat != null && v.lng != null) {
          return { pt: { lat: v.lat, lng: v.lng }, label: displayName(v.name), kind: "first", skipId: v.id };
        }
      }
    }
    return null;
  }

  function updateOptimizeEnabled() {
    var btn = $("vac-v2-optimize");
    if (!btn) return;
    var start = getRouteStart();
    var unvis = 0;
    for (var i = 0; i < visitQueue.length; i++) {
      var v = findVeteranById(visitQueue[i].id);
      if (v && v.lat != null && v.lng != null) unvis++;
    }
    btn.disabled = !start || unvis < 2 || visitRouteLoading;
    btn.title = !start
      ? "請先 GPS 或點地圖設定我的位置（或勾選以清單第 1 為起點）"
      : (unvis < 2 ? "至少需 2 個未訪且有座標的訪點" : "固定起點；nearest-neighbor＋2-opt（近似，非絕對最優）");
  }

  function updateTodayProgress() {
    var done = visitedList.length;
    var total = visitQueue.length + done;
    var elp = $("vac-v2-today-text");
    if (elp) elp.textContent = "今日進度 " + done + "／" + total;
    var db = $("vac-v2-done-toggle");
    if (db) db.textContent = "已訪清單" + (done ? "（" + done + "）" : "");
    updateOptimizeEnabled();
  }

  function initVisitWorkspace() {
    if (!window.confirm("初始化將清除已匯入的訪視對象、排訪與已訪清單，並重設篩選。門牌索引保留。確定？")) return;
    veterans = [];
    visitQueue = [];
    visitedList = [];
    persistVisitQueue();
    listZoneFilter = "";
    listNetFilter = "";
    listBdayFilter = "";
    listStatusFilter = "";
    birthdayMonth = "";
    persistListFilters();
    if ($("vac-v2-search")) $("vac-v2-search").value = "";
    if ($("vac-v2-flt-zone")) $("vac-v2-flt-zone").value = "";
    if ($("vac-v2-flt-net")) $("vac-v2-flt-net").value = "";
    if ($("vac-v2-flt-bday")) $("vac-v2-flt-bday").value = "";
    visitRouteSegs = [];
    if (visitRouteLayer) visitRouteLayer.clearLayers();
    if (cluster) cluster.clearLayers();
    fillListFilters();
    renderVeteranList();
    renderVisitQueue();
    renderDoneList();
    refreshMarkers();
    updateTodayProgress();
    persistState();
    toast("已初始化訪視名單（門牌保留）。", "ok", 2800);
  }

  function addToVisit(id) {
    if (doneIndexOf(id) >= 0) {
      toast("此人已在已訪清單", "warn", 2200);
      showDonePanel = true;
      applyDonePanelVis();
      renderDoneList();
      return;
    }
    if (visitIndexOf(id) >= 0) {
      ensureVisitQueueVisible();
      focusVisitId = id;
      renderVisitQueue();
      toast("已在排訪清單", "warn", 2000);
      return;
    }
    visitQueue.push({ id: id });
    persistVisitQueue();
    ensureVisitQueueVisible();
    focusVisitId = id;
    renderVeteranList();
    renderVisitQueue();
    refreshMarkers();
    updateTodayProgress();
    scheduleVisitRoute();
    toast("已加入排訪", "ok", 1800);
  }

  function removeFromVisit(id) {
    var i = visitIndexOf(id);
    if (i < 0) return;
    visitQueue.splice(i, 1);
    persistVisitQueue();
    renderVeteranList();
    renderVisitQueue();
    refreshMarkers();
    updateTodayProgress();
    scheduleVisitRoute();
  }

  function setVisited(id, on) {
    if (on) {
      var qi = visitIndexOf(id);
      if (qi >= 0) visitQueue.splice(qi, 1);
      if (doneIndexOf(id) < 0) visitedList.push({ id: id, at: Date.now() });
      toast("已移入已訪清單，路徑已更新", "ok", 2000);
    } else {
      var di = doneIndexOf(id);
      if (di >= 0) visitedList.splice(di, 1);
      if (visitIndexOf(id) < 0) visitQueue.push({ id: id });
      toast("已從已訪清單回到排訪", "ok", 2000);
    }
    persistVisitQueue();
    renderVeteranList();
    renderVisitQueue();
    renderDoneList();
    refreshMarkers();
    updateTodayProgress();
    scheduleVisitRoute();
  }

  function netsForZoneName(zoneName) {
    var out = {};
    veterans.forEach(function (v) {
      if (String(v.zone || "") !== zoneName) return;
      var net = String(v.net || "").trim();
      if (net) out[net] = true;
    });
    document.querySelectorAll(".vac-editor-row").forEach(function (row) {
      var selZ = row.querySelector(".vac-zone-select");
      var selN = row.querySelector(".vac-net-select");
      var z = selZ ? selZ.value : (row.getAttribute("data-zone") || "");
      if (z !== zoneName) return;
      var net = String(selN ? selN.value : (row.getAttribute("data-net") || "")).trim();
      if (net) out[net] = true;
    });
    return out;
  }

  function netsForZoneUnion(zoneName) {
    var out = netsForZoneName(zoneName);
    if (typeof window.__vacNetsUsedByZone === "function") {
      var more = window.__vacNetsUsedByZone(zoneName) || {};
      Object.keys(more).forEach(function (k) { out[k] = true; });
    }
    return out;
  }

  function applyZoneNetLink(zoneCb) {
    if (!zoneCb) return;
    var mine = netsForZoneUnion(zoneCb.value);
    var still = {};
    if (!zoneCb.checked) {
      document.querySelectorAll(".vac-zone-cb:checked").forEach(function (cb) {
        var nets = netsForZoneUnion(cb.value);
        Object.keys(nets).forEach(function (n) { still[n] = true; });
      });
    }
    syncingZoneNets = true;
    var added = [];
    var removed = [];
    document.querySelectorAll(".vac-net-cb").forEach(function (cb) {
      if (zoneCb.checked) {
        if (mine[cb.value] && !cb.checked) {
          cb.checked = true;
          added.push(cb.value);
        }
      } else if (mine[cb.value] && !still[cb.value] && cb.checked) {
        cb.checked = false;
        removed.push(cb.value);
      }
    });
    syncingZoneNets = false;
    if (added.length) toast("已連動勾選服務網 " + added.join("、"), "ok", 2200);
    else if (removed.length) toast("已取消只屬於此區的服務網 " + removed.join("、"), "ok", 2200);
  }

  function formatZone(z) {
    var s = String(z || "").trim();
    if (!s) return "—";
    if (/責任區/.test(s)) return s.replace(/^第/, "").replace(/責任區$/, "區");
    return s;
  }
  function formatNet(n) {
    var s = String(n || "").trim();
    if (!s) return "—";
    if (/服務網/.test(s)) return s.replace(/^第/, "").replace(/服務網$/, "網");
    return s;
  }

  function focusVeteranOnMap(v, orderNum) {
    if (!v) return;
    if (v.lat == null || v.lng == null) {
      toast((v.reason || "尚未對到座標") + " — " + displayName(v.name), "warn", 3200);
      return;
    }
    if (!map) return;
    map.setView([v.lat, v.lng], Math.max(map.getZoom() || 15, 17));
    var open = function () {
      if (v._marker && v._marker.openPopup) v._marker.openPopup();
    };
    if (v._marker && cluster && typeof cluster.zoomToShowLayer === "function") {
      try { cluster.zoomToShowLayer(v._marker, open); }
      catch (e) { open(); }
    } else {
      open();
    }
    redrawVisitRoute();
    if (orderNum != null) toast("排訪第 " + orderNum + " 位　" + displayName(v.name), "ok", 1600);
  }

  function onRowClick(ev) {
    var i = Number(ev.currentTarget.getAttribute("data-i"));
    var v = veterans[i];
    if (!v) return;
    focusVeteranOnMap(v, isQueued(v.id) ? visitIndexOf(v.id) + 1 : null);
  }

  function syncImportFold() {
    var vets = $("vac-v2-veterans");
    var btn = $("vac-v2-fold-import");
    if (!vets || !btn) return;
    var phone = window.innerWidth < 700;
    btn.hidden = !phone;
    if (!phone) {
      vets.classList.remove("is-folded");
      return;
    }
    var fold;
    if (vets.dataset.userFold === "1") fold = true;
    else if (vets.dataset.userFold === "0") fold = false;
    else {
      var saved = null;
      try { saved = localStorage.getItem("vac-v2-import-folded"); } catch (e) {}
      if (saved === "1") fold = true;
      else if (saved === "0") fold = false;
      else fold = veterans.length > 0;
    }
    if (!veterans.length) fold = false;
    vets.classList.toggle("is-folded", !!fold);
    btn.textContent = fold ? "顯示匯入工具" : "收合匯入工具";
  }

  function renderVeteranList() {
    var empty = $("vac-v2-empty");
    var list = $("vac-v2-vlist");
    var stEl = $("vac-v2-stats");
    cachedFilter = null;
    var snap = getFilterSnap();
    var q = snap.q;
    if (!list) return;
    if (!veterans.length) {
      if (empty) {
        empty.style.display = "";
        empty.textContent = q
          ? "請先按『匯入訪視對象 CSV』；搜尋僅作用於已匯入名單"
          : "尚未匯入訪視對象。請於右側訪視頁匯入訪視對象 CSV（Big5 或 UTF-8）。個資只留在本機。";
      }
      list.textContent = "";
      if (stEl) stEl.textContent = "";
      updateTodayProgress();
      syncImportFold();
      return;
    }
    if (empty) empty.style.display = "none";
    var s = stats();
    if (stEl) {
      stEl.textContent = "";
      function addStat(label, n, key, cls) {
        var b = document.createElement("button");
        b.type = "button";
        b.className = "vac-v2-stat-chip" + (cls ? " " + cls : "") + (listStatusFilter === key ? " is-on" : "");
        b.textContent = label + " " + n;
        b.addEventListener("click", function () {
          listStatusFilter = listStatusFilter === key ? "" : key;
          scheduleFilterRefresh();
        });
        stEl.appendChild(b);
      }
      addStat("已定位", s.a, "ok", "");
      addStat("低信心", s.b, "low", "");
      addStat("失敗", s.c, "fail", "is-fail");
      var rest = document.createElement("span");
      rest.className = "vac-v2-stat-rest";
      rest.textContent = "／共 " + s.n + (doorReady ? "（門牌 " + doorCount + "）" : "（尚未匯入門牌）") +
        "　點「失敗」只看對不到的；「匯出失敗 Excel」含失敗類型與對照新里。";
      stEl.appendChild(rest);
    }
    var cap = listCap > 0 ? listCap : veterans.length;
    var shown = 0;
    var matched = 0;
    var frag = document.createDocumentFragment();
    for (var i = 0; i < veterans.length; i++) {
      var v = veterans[i];
      if (!veteranPassesFilter(v, q, snap)) continue;
      matched++;
      if (shown >= cap) continue;
      shown++;
      var row = document.createElement("div");
      row.className = "vac-v2-vrow vac-v2-visit-row";
      row.setAttribute("role", "listitem");
      row.setAttribute("data-i", String(i));
      row.setAttribute("data-id", String(v.id));
      var sem = visitSemantic(v);
      if (sem === "queued") row.classList.add("is-queued");
      if (sem === "done") row.classList.add("is-done");

      var cZone = document.createElement("span");
      cZone.className = "c-zone";
      cZone.textContent = formatZone(v.zone);
      var cNet = document.createElement("span");
      cNet.className = "c-net";
      cNet.textContent = formatNet(v.net);
      var cB = document.createElement("span");
      cB.className = "c-bday";
      cB.textContent = v.birthMonth ? (v.birthMonth + "月") : "—";
      var cNm = document.createElement("span");
      cNm.className = "c-nm";
      var nmTxt = document.createElement("span");
      nmTxt.textContent = displayName(v.name);
      if (sem === "done") nmTxt.style.textDecoration = "line-through";
      cNm.appendChild(nmTxt);
      var ch = chipLabel(v.status);
      var chip = document.createElement("span");
      chip.className = "vac-v2-chip " + ch.cls;
      chip.textContent = ch.text;
      if (v.reason) chip.title = v.reason;
      cNm.appendChild(chip);

      var cAddr = document.createElement("span");
      cAddr.className = "c-addr";
      var addrBtn = document.createElement("button");
      addrBtn.type = "button";
      addrBtn.className = "vac-v2-addr-btn";
      var expanded = !!expandedAddrs[v.id];
      addrBtn.textContent = expanded ? "隱藏" : "地址";
      addrBtn.title = expanded ? (v.address || "") : "顯示完整地址";
      addrBtn.addEventListener("click", (function (vid, ev) {
        return function (e) {
          e.stopPropagation();
          expandedAddrs[vid] = !expandedAddrs[vid];
          renderVeteranList();
        };
      })(v.id));
      cAddr.appendChild(addrBtn);
      if (expanded) {
        var addrTxt = document.createElement("div");
        addrTxt.className = "vac-v2-addr-full";
        addrTxt.textContent = v.address || "（無地址）";
        cAddr.appendChild(addrTxt);
      }

      var cAct = document.createElement("span");
      cAct.className = "c-act";
      var addBtn = document.createElement("button");
      addBtn.type = "button";
      addBtn.className = "vac-v2-btn vac-v2-add-btn";
      if (isVisited(v.id)) {
        addBtn.textContent = "已訪";
        addBtn.disabled = true;
      } else if (isQueued(v.id)) {
        addBtn.textContent = "已在排訪";
        addBtn.disabled = true;
      } else {
        addBtn.textContent = "加入排訪";
        addBtn.addEventListener("click", (function (vid) {
          return function (e) { e.stopPropagation(); addToVisit(vid); };
        })(v.id));
      }
      cAct.appendChild(addBtn);

      row.appendChild(cZone);
      row.appendChild(cNet);
      row.appendChild(cB);
      row.appendChild(cNm);
      row.appendChild(cAddr);
      row.appendChild(cAct);

      row.addEventListener("click", onRowClick);
      frag.appendChild(row);
    }
    list.textContent = "";
    list.appendChild(frag);
    if (shown === 0) {
      if (empty) {
        empty.style.display = "";
        empty.textContent = q || birthdayMonth
          ? "找不到符合篩選的姓名／地址"
          : "目前篩選無資料（請檢查責任區／服務網勾選）";
      }
    }
    if (matched > cap) {
      var more = document.createElement("div");
      more.className = "vac-v2-empty";
      more.textContent = "僅顯示前 " + cap + " 筆（符合 " + matched + " 筆）。可把「顯示筆數」調高或選「全部」。";
      list.appendChild(more);
    }
    updateTodayProgress();
    syncImportFold();
  }

  function renderVisitQueue() {
    var ql = $("vac-v2-qlist");
    if (!ql) return;
    ql.textContent = "";
    if (!showVisitPanel) {
      ql.style.display = "none";
      return;
    }
    ql.style.display = "";
    var qTitle = $("vac-v2-q-title");
    if (qTitle) {
      qTitle.textContent = visitQueue.length ? ("排訪清單（" + visitQueue.length + "）") : "排訪清單";
    }
    if (!visitQueue.length) {
      var emp = document.createElement("div");
      emp.className = "vac-v2-empty";
      emp.textContent = "從上方列表加入訪點";
      ql.appendChild(emp);
      return;
    }
    var head = document.createElement("div");
    head.className = "vac-v2-qcols";
    ["序", "姓名", "完整地址", "責任區", "服務網", "生日月", "已訪", ""].forEach(function (t) {
      head.appendChild(el("span", { text: t }));
    });
    ql.appendChild(head);

    visitQueue.forEach(function (item, idx) {
      var v = findVeteranById(item.id);
      if (!v) return;
      var row = document.createElement("div");
      row.className = "vac-v2-qrow" + (item.visited ? " is-done" : "");
      row.setAttribute("role", "listitem");
      row.setAttribute("draggable", "true");
      row.setAttribute("data-qi", String(idx));
      row.setAttribute("data-id", String(v.id));
      row.title = "點一下地圖置中並顯示序號";
      if (focusVisitId === v.id) row.classList.add("is-focus");

      var handle = document.createElement("span");
      handle.className = "vac-v2-drag";
      handle.textContent = "⋮⋮ " + (idx + 1);
      handle.title = "拖曳重排";

      var nm = document.createElement("span");
      nm.className = "q-nm";
      nm.textContent = displayName(v.name);

      var addr = document.createElement("span");
      addr.className = "q-addr";
      addr.textContent = v.address || "—";
      addr.title = v.address || "";

      var zn = document.createElement("span");
      zn.textContent = formatZone(v.zone);
      var nt = document.createElement("span");
      nt.textContent = formatNet(v.net);
      var bd = document.createElement("span");
      bd.textContent = v.birthMonth ? (v.birthMonth + "月") : "—";

      var lab = document.createElement("label");
      lab.className = "q-vis";
      var cb = document.createElement("input");
      cb.type = "checkbox";
      cb.checked = !!item.visited;
      cb.addEventListener("change", (function (vid) {
        return function (e) { e.stopPropagation(); setVisited(vid, e.target.checked); };
      })(v.id));
      lab.appendChild(cb);

      var rm = document.createElement("button");
      rm.type = "button";
      rm.className = "vac-v2-btn vac-v2-rm-btn";
      rm.textContent = "移除";
      rm.addEventListener("click", (function (vid) {
        return function (e) { e.stopPropagation(); removeFromVisit(vid); };
      })(v.id));

      row.appendChild(handle);
      row.appendChild(nm);
      row.appendChild(addr);
      row.appendChild(zn);
      row.appendChild(nt);
      row.appendChild(bd);
      row.appendChild(lab);
      row.appendChild(rm);

      row.addEventListener("click", function (ev) {
        if (ev.target && ev.target.closest && (ev.target.closest("button") || ev.target.closest("input") || ev.target.closest("label"))) return;
        focusVisitId = v.id;
        focusVeteranOnMap(v, idx + 1);
        var sibs = ql.querySelectorAll(".vac-v2-qrow");
        for (var si = 0; si < sibs.length; si++) sibs[si].classList.toggle("is-focus", sibs[si] === row);
      });

      row.addEventListener("dragstart", function (ev) {
        ev.dataTransfer.setData("text/plain", String(idx));
        ev.dataTransfer.effectAllowed = "move";
        row.classList.add("is-dragging");
      });
      row.addEventListener("dragend", function () { row.classList.remove("is-dragging"); });
      row.addEventListener("dragover", function (ev) {
        ev.preventDefault();
        ev.dataTransfer.dropEffect = "move";
        row.classList.add("is-drop");
      });
      row.addEventListener("dragleave", function () { row.classList.remove("is-drop"); });
      row.addEventListener("drop", function (ev) {
        ev.preventDefault();
        row.classList.remove("is-drop");
        var from = Number(ev.dataTransfer.getData("text/plain"));
        var to = Number(row.getAttribute("data-qi"));
        if (!isFinite(from) || !isFinite(to) || from === to) return;
        var moved = visitQueue.splice(from, 1)[0];
        visitQueue.splice(to, 0, moved);
        persistVisitQueue();
        renderVisitQueue();
        refreshMarkers();
        scheduleVisitRoute();
      });

      ql.appendChild(row);
    });
  }

  function renderDoneList() {
    var dl = $("vac-v2-dlist");
    if (!dl) return;
    dl.textContent = "";
    if (!visitedList.length) {
      var emp = document.createElement("div");
      emp.className = "vac-v2-empty";
      emp.textContent = "勾選排訪清單「已訪」後會移入這裡，地圖路徑一併拿掉。";
      dl.appendChild(emp);
      return;
    }
    var head = document.createElement("div");
    head.className = "vac-v2-qcols";
    ["#", "姓名", "完整地址", "責任區", "服務網", "生日月", "已訪", ""].forEach(function (t) {
      head.appendChild(el("span", { text: t }));
    });
    dl.appendChild(head);
    visitedList.forEach(function (item, idx) {
      var v = findVeteranById(item.id);
      if (!v) return;
      var row = document.createElement("div");
      row.className = "vac-v2-qrow is-done";
      row.setAttribute("role", "listitem");
      row.setAttribute("data-id", String(v.id));
      row.title = "點一下地圖置中（已訪）";

      var no = document.createElement("span");
      no.className = "vac-v2-drag";
      no.textContent = String(idx + 1);

      var nm = document.createElement("span");
      nm.className = "q-nm";
      nm.textContent = displayName(v.name);

      var addr = document.createElement("span");
      addr.className = "q-addr";
      addr.textContent = v.address || "—";
      addr.title = v.address || "";

      var zn = document.createElement("span");
      zn.textContent = formatZone(v.zone);
      var nt = document.createElement("span");
      nt.textContent = formatNet(v.net);
      var bd = document.createElement("span");
      bd.textContent = v.birthMonth ? (v.birthMonth + "月") : "—";

      var lab = document.createElement("label");
      lab.className = "q-vis";
      var cb = document.createElement("input");
      cb.type = "checkbox";
      cb.checked = true;
      cb.title = "取消勾選可回到排訪清單";
      cb.addEventListener("change", (function (vid) {
        return function (e) { e.stopPropagation(); setVisited(vid, e.target.checked); };
      })(v.id));
      lab.appendChild(cb);

      var rm = document.createElement("button");
      rm.type = "button";
      rm.className = "vac-v2-btn vac-v2-rm-btn";
      rm.textContent = "移除";
      rm.addEventListener("click", (function (vid) {
        return function (e) {
          e.stopPropagation();
          var di = doneIndexOf(vid);
          if (di >= 0) visitedList.splice(di, 1);
          persistVisitQueue();
          renderVeteranList();
          renderDoneList();
          refreshMarkers();
          updateTodayProgress();
        };
      })(v.id));

      row.appendChild(no);
      row.appendChild(nm);
      row.appendChild(addr);
      row.appendChild(zn);
      row.appendChild(nt);
      row.appendChild(bd);
      row.appendChild(lab);
      row.appendChild(rm);
      row.addEventListener("click", function (ev) {
        if (ev.target && ev.target.closest && (ev.target.closest("button") || ev.target.closest("input") || ev.target.closest("label"))) return;
        focusVisitId = v.id;
        focusVeteranOnMap(v, null);
      });
      dl.appendChild(row);
    });
  }

  function markerColors(v) {
    var sem = visitSemantic(v);
    var isLow = v.status === "low";
    if (sem === "done") {
      return { fill: VISIT_DONE, stroke: "#37474f", dash: null, weight: 2 };
    }
    if (sem === "queued") {
      return { fill: VISIT_QUEUED, stroke: "#4a148c", dash: null, weight: 3 };
    }
    if (isLow) {
      return { fill: LOW_COLOR, stroke: LOW_COLOR, dash: "4,3", weight: 2 };
    }
    return { fill: VISIT_PENDING, stroke: "#0d47a1", dash: null, weight: 2 };
  }



  function markerFor(v, orderBadge) {
    var cols = markerColors(v);
    var mk = L.circleMarker([v.lat, v.lng], {
      radius: 7,
      color: cols.stroke,
      weight: cols.weight,
      dashArray: cols.dash,
      fillColor: cols.fill,
      fillOpacity: 0.92
    });
    if (orderBadge != null) {
      var icon = L.divIcon({
        className: "vac-v2-order-badge",
        html: '<div class="vac-v2-badge-num">' + String(orderBadge) + "</div>",
        iconSize: [22, 22],
        iconAnchor: [11, 11]
      });
      var badge = L.marker([v.lat, v.lng], { icon: icon, interactive: false, keyboard: false });
      v._badge = badge;
    }
    var pop = document.createElement("div");
    var t = document.createElement("div");
    t.style.fontWeight = "800";
    t.textContent = displayName(v.name) + (v.zone ? ("　責任區 " + v.zone) : "");
    var a = document.createElement("div");
    a.style.marginTop = "4px";
    a.textContent = v.address || "";
    var c = document.createElement("div");
    c.style.marginTop = "4px";
    c.style.color = cols.fill;
    var sem = visitSemantic(v);
    var semLabel = sem === "done" ? "已訪" : (sem === "queued" ? "排訪中" : "待受訪");
    if (v.status === "low") semLabel += " · 低信心";
    else if (v.status === "ok") semLabel += " · 已定位";
    c.textContent = semLabel + (v.reason ? "（" + v.reason + "）" : "");
    var titleRow = document.createElement("div");
    titleRow.className = "vac-v2-pop-head";
    titleRow.appendChild(t);
    var addPop = document.createElement("button");
    addPop.type = "button";
    addPop.className = "vac-v2-btn vac-v2-pop-add";
    if (isVisited(v.id)) {
      addPop.textContent = "已訪";
      addPop.disabled = true;
    } else if (isQueued(v.id)) {
      addPop.textContent = "已在排訪";
      addPop.disabled = true;
    } else {
      addPop.textContent = "加入排訪";
      addPop.addEventListener("click", function (e) {
        e.preventDefault();
        e.stopPropagation();
        addToVisit(v.id);
        addPop.textContent = "已在排訪";
        addPop.disabled = true;
      });
    }
    titleRow.appendChild(addPop);
    pop.appendChild(titleRow);
    pop.appendChild(a);
    pop.appendChild(c);
    if (v.aliasNote && String(v.aliasNote).indexOf("已套用") === 0) {
      var al = document.createElement("div");
      al.style.marginTop = "4px";
      al.style.fontSize = "11px";
      al.style.color = "#1565c0";
      al.textContent = v.aliasNote;
      pop.appendChild(al);
    }
    mk.bindPopup(pop);
    v._marker = mk;
    return mk;
  }

  function refreshMarkers() {
    ensureCluster();
    cluster.clearLayers();
    cachedFilter = null;
    var snap = getFilterSnap();
    var q = snap.q;
    for (var i = 0; i < veterans.length; i++) {
      var v = veterans[i];
      v._marker = null;
      v._badge = null;
      if (v.status !== "ok" && v.status !== "low") continue;
      if (v.lat == null || v.lng == null) continue;
      if (!veteranPassesFilter(v, q, snap) && !isQueued(v.id) && !isVisited(v.id)) continue;
      cluster.addLayer(markerFor(v, null));
    }
    var vetLayer = $("vac-layer-vet");
    if (vetLayer && vetLayer.checked && cluster && map && !map.hasLayer(cluster)) {
      cluster.addTo(map);
    }
    redrawVisitRoute();
  }

  function ensureVisitRouteLayer() {
    if (!visitRouteLayer && map) visitRouteLayer = L.layerGroup().addTo(map);
    return visitRouteLayer;
  }

  function visitPathPoints() {
    var start = getRouteStart();
    var pts = [];
    if (!start) return pts;
    pts.push(start.pt);
    for (var i = 0; i < visitQueue.length; i++) {
      var v = findVeteranById(visitQueue[i].id);
      if (!v || v.lat == null || v.lng == null) continue;
      if (start.kind === "first" && start.skipId === v.id) continue;
      pts.push({ lat: v.lat, lng: v.lng });
    }
    return pts;
  }

  function redrawVisitRoute() {
    var layer = ensureVisitRouteLayer();
    if (!layer) return;
    layer.clearLayers();
    if (visitRouteSegs.length) {
      for (var i = 0; i < visitRouteSegs.length; i++) {
        var seg = visitRouteSegs[i];
        var latlngs = (seg.coords || []).map(function (pt) { return [pt.lat, pt.lng]; });
        if (latlngs.length >= 2) {
          layer.addLayer(L.polyline(latlngs, {
            color: seg.mode === "straight" ? "#8e24aa" : VISIT_QUEUED,
            weight: seg.mode === "straight" ? 3 : 4,
            opacity: 0.85,
            dashArray: seg.mode === "straight" ? "6,8" : null
          }));
        }
      }
    }
    for (var qi = 0; qi < visitQueue.length; qi++) {
      var vv = findVeteranById(visitQueue[qi].id);
      if (!vv || vv.lat == null || vv.lng == null) continue;
      var on = focusVisitId === vv.id;
      var icon = L.divIcon({
        className: "vac-v2-order-badge" + (on ? " is-focus" : ""),
        html: '<div class="vac-v2-badge-num' + (on ? " is-focus" : "") + '">' + String(qi + 1) + "</div>",
        iconSize: on ? [28, 28] : [22, 22],
        iconAnchor: on ? [14, -8] : [11, -6]
      });
      layer.addLayer(L.marker([vv.lat, vv.lng], { icon: icon, interactive: false, keyboard: false }));
    }
    updateVisitRouteHud();
  }

  function visitRouteKm() {
    var km = 0;
    for (var i = 0; i < visitRouteSegs.length; i++) km += visitRouteSegs[i].km || 0;
    return km;
  }

  function visitRouteModeSummary() {
    if (visitRouteLoading) return "loading";
    if (!visitRouteSegs.length) return "none";
    var st = 0;
    for (var i = 0; i < visitRouteSegs.length; i++) if (visitRouteSegs[i].mode === "straight") st++;
    if (st === visitRouteSegs.length) return "straight";
    if (st > 0) return "mixed";
    return "route";
  }

  function updateVisitRouteHud() {
    var hud = $("vac-v2-hud");
    var metrics = $("vac-v2-metrics");
    /* Prefer measure HUD when actively measuring with verts */
    if (measuring && measureVerts.length) return;
    var start = getRouteStart();
    var pts = visitPathPoints();
    if (!visitQueue.length) {
      if (hud && !measuring) {
        hud.classList.remove("is-on", "is-warn");
      }
      return;
    }
    if (!start) {
      if (hud) {
        hud.classList.add("is-on", "is-warn");
        hud.textContent = "請先 GPS 或點地圖設定我的位置";
      }
      return;
    }
    if (pts.length < 2) {
      if (hud) {
        hud.classList.add("is-on");
        hud.classList.remove("is-warn");
        hud.textContent = "排訪起點已設 · 再加入訪點以規劃路徑";
      }
      return;
    }
    var km = visitRouteKm();
    var mode = visitRouteModeSummary();
    var modeTxt = mode === "loading" ? "路由計算中…"
      : mode === "straight" ? "直線（路由失敗／離線）"
      : mode === "mixed" ? "部分路段為直線"
      : "沿道路";
    var msg = "排訪路徑 · " + modeTxt + " · " + formatDist(km) + " · 約 " + etaMinutes(km) + " 分";
    if (hud) {
      hud.classList.add("is-on");
      hud.classList.toggle("is-warn", mode === "straight" || mode === "mixed");
      hud.textContent = msg;
    }
    if (metrics && !measureVerts.length) metrics.textContent = formatDist(km) + " · " + etaMinutes(km) + " 分";
  }

  function scheduleVisitRoute() {
    if (visitRouteTimer) clearTimeout(visitRouteTimer);
    visitRouteTimer = setTimeout(function () { recomputeVisitRoute(); }, 200);
  }

  async function recomputeVisitRoute() {
    var myGen = ++visitRouteGen;
    var pts = visitPathPoints();
    if (pts.length < 2) {
      visitRouteSegs = [];
      visitRouteLoading = false;
      redrawVisitRoute();
      updateOptimizeEnabled();
      return;
    }
    visitRouteLoading = true;
    updateOptimizeEnabled();
    updateVisitRouteHud();
    var segs = [];
    for (var i = 1; i < pts.length; i++) {
      if (myGen !== visitRouteGen) return;
      var seg = await fetchOsrmSegment(pts[i - 1], pts[i]);
      if (!seg || !seg.coords || seg.coords.length < 2) {
        seg = {
          mode: "straight",
          km: haversineKm(pts[i - 1], pts[i]),
          coords: [pts[i - 1], pts[i]]
        };
      }
      segs.push(seg);
    }
    if (myGen !== visitRouteGen) return;
    visitRouteSegs = segs;
    visitRouteLoading = false;
    redrawVisitRoute();
    updateOptimizeEnabled();
    var mode = visitRouteModeSummary();
    if (mode === "straight" || mode === "mixed") {
      toast(mode === "straight" ? "排訪路徑：直線（路由失敗／離線）" : "排訪路徑：部分路段為直線", "warn", 3200);
    }
  }

  function nearestNeighborOrder(start, nodes) {
    var left = nodes.slice();
    var ordered = [];
    var cur = start;
    while (left.length) {
      var best = 0;
      var bestD = Infinity;
      for (var i = 0; i < left.length; i++) {
        var d = haversineKm(cur, left[i]);
        if (d < bestD) { bestD = d; best = i; }
      }
      var n = left.splice(best, 1)[0];
      ordered.push(n);
      cur = n;
    }
    return ordered;
  }

  function pathLen(start, ordered) {
    var km = 0;
    var cur = start;
    for (var i = 0; i < ordered.length; i++) {
      km += haversineKm(cur, ordered[i]);
      cur = ordered[i];
    }
    return km;
  }

  function twoOpt(start, ordered) {
    var arr = ordered.slice();
    var improved = true;
    var guard = 0;
    while (improved && guard < 40) {
      improved = false;
      guard++;
      for (var i = 0; i < arr.length - 1; i++) {
        for (var k = i + 1; k < arr.length; k++) {
          var next = arr.slice(0, i).concat(arr.slice(i, k + 1).reverse(), arr.slice(k + 1));
          if (pathLen(start, next) + 1e-9 < pathLen(start, arr)) {
            arr = next;
            improved = true;
          }
        }
      }
    }
    return arr;
  }

  async function optimizeVisitOrder() {
    var startInfo = getRouteStart();
    if (!startInfo) {
      toast("請先 GPS 或點地圖設定我的位置（或勾選以清單第 1 為起點）", "warn", 4200);
      return;
    }
    var unvis = [];
    var visitedKeep = [];
    for (var i = 0; i < visitQueue.length; i++) {
      var it = visitQueue[i];
      var v = findVeteranById(it.id);
      if (!v) continue;
      if (it.visited) {
        visitedKeep.push(it);
        continue;
      }
      if (v.lat == null || v.lng == null) {
        visitedKeep.push(it); /* no coords: keep relative at end block */
        continue;
      }
      if (startInfo.kind === "first" && startInfo.skipId === v.id) {
        unvis.push({ id: v.id, lat: v.lat, lng: v.lng, isStartAnchor: true });
      } else {
        unvis.push({ id: v.id, lat: v.lat, lng: v.lng });
      }
    }
    var nodes = unvis.filter(function (n) { return !n.isStartAnchor; });
    if (nodes.length < 2 && !(unvis.length >= 2)) {
      toast("至少需要 2 個未訪且有座標的訪點才能優化", "warn", 3200);
      return;
    }
    if (nodes.length > OPTIMIZE_WARN_N) {
      if (!window.confirm("未訪點超過 " + OPTIMIZE_WARN_N + " 個，建議分批優化。仍要繼續？（近似演算法，非絕對最優）")) {
        return;
      }
    }
    var btn = $("vac-v2-optimize");
    if (btn) { btn.disabled = true; btn.textContent = "優化中…"; }
    await yieldUI();
    try {
      var start = startInfo.pt;
      var ordered = nearestNeighborOrder(start, nodes);
      ordered = twoOpt(start, ordered);
      var newQ = [];
      /* if first-as-start anchor exists, put it first */
      for (var a = 0; a < unvis.length; a++) {
        if (unvis[a].isStartAnchor) newQ.push({ id: unvis[a].id, visited: false });
      }
      for (var o = 0; o < ordered.length; o++) newQ.push({ id: ordered[o].id, visited: false });
      for (var vki = 0; vki < visitedKeep.length; vki++) newQ.push(visitedKeep[vki]);
      visitQueue = newQ;
      persistVisitQueue();
      renderVeteranList();
      renderVisitQueue();
      refreshMarkers();
      scheduleVisitRoute();
      toast("已優化訪序（nearest-neighbor＋2-opt 近似）", "ok", 3500);
    } catch (err) {
      toast("優化失敗，已保留原序", "error", 3500);
    }
    if (btn) { btn.textContent = "優化訪序"; }
    updateOptimizeEnabled();
  }

  function csvEsc(s) {
    s = String(s == null ? "" : s);
    if (/[",\n]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
    return s;
  }

  function downloadTextFile(name, text) {
    var blob = new Blob(["\ufeff" + text], { type: "text/csv;charset=utf-8" });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = name;
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  }

  function sheetFromTextRows(XLSX, rows) {
    var ws = {};
    var maxC = 1;
    for (var r = 0; r < rows.length; r++) {
      var line = rows[r] || [];
      if (line.length > maxC) maxC = line.length;
      for (var c = 0; c < line.length; c++) {
        ws[XLSX.utils.encode_cell({ r: r, c: c })] = {
          t: "s",
          v: line[c] == null ? "" : String(line[c])
        };
      }
    }
    ws["!ref"] = XLSX.utils.encode_range({
      s: { r: 0, c: 0 },
      e: { r: Math.max(rows.length - 1, 0), c: Math.max(maxC - 1, 0) }
    });
    if (rows[0] && rows[0].length) {
      ws["!cols"] = rows[0].map(function (h, i) {
        var w = String(h || "").length;
        var limit = Math.min(rows.length, 30);
        for (var rr = 1; rr < limit; rr++) {
          var n = String((rows[rr] || [])[i] == null ? "" : rows[rr][i]).length;
          if (n > w) w = n;
        }
        return { wch: Math.min(Math.max(w + 2, 8), 42) };
      });
    }
    return ws;
  }

  function downloadXlsxRows(filename, rows, sheetName) {
    return loadSheetJs().then(function () {
      var XLSX = window.XLSX;
      if (!XLSX || !XLSX.writeFile) throw new Error("Excel 元件尚未載入");
      var wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, sheetFromTextRows(XLSX, rows), String(sheetName || "資料").slice(0, 31));
      XLSX.writeFile(wb, filename, { bookType: "xlsx", compression: true });
    });
  }

  function downloadSampleCsv() {
    var rows = [
      ["姓名", "責任區", "服務區", "生日月份", "通訊地址"],
      ["測試甲", "6", "21", "1", "高雄市左營區自助里16鄰崇實路347號"],
      ["測試乙", "6", "21", "2", "高雄市左營區自由三路1之1號"],
      ["測試丙", "6", "21", "3", "高雄市鼓山區美術東二路10號3樓"],
      ["測試丁", "6", "21", "4", "高雄市測試區沒有這條路99號"]
    ];
    downloadXlsxRows("訪視對象-示範.xlsx", rows, "訪視示範").then(function () {
      toast("已下載示範 Excel（欄位：姓名、責任區、服務區、生日月份、通訊地址）", "ok", 3200);
    }).catch(function (e) {
      toast((e && e.message) || "無法匯出 Excel", "error", 4000);
    });
  }

  function failKindLabel(kind) {
    var map = {
      "no-pack": "尚未匯入門牌",
      "no-number": "無門牌號碼",
      "xref-not-in-pack": "對照表有此號，門牌索引沒有",
      "xref-missing-scan": "對照表缺頁（掃描檔）",
      "old-li-split": "舊里一對多",
      "old-li-mapped": "已轉新里仍無門牌",
      "not-in-index": "門牌索引與對照表都無此號"
    };
    return map[kind] || (kind || "地址對不到門牌");
  }

  function exportFailCsv() {
    var rows = veterans.filter(function (v) { return v && (v.status === "fail" || v.status === "pend"); });
    if (!rows.length) {
      toast("目前沒有對位失敗的名單", "warn", 2800);
      return;
    }
    var aoa = [["檔案列號", "姓名", "責任區", "服務網", "生日月份", "通訊地址", "失敗類型", "失敗原因", "對照舊里", "對照新里"]];
    rows.forEach(function (v) {
      var townLi = extractTownLi(v.address);
      var alias = townLi ? lookupLiAlias(townLi.town, townLi.li) : null;
      var c = classifyAddrFail(v.address, alias);
      var kind = v.failKind || (v.status === "pend" ? "no-pack" : c.kind);
      var reason = v.reason || c.reason || "地址對不到門牌";
      if (v.status === "pend") {
        kind = "no-pack";
        reason = v.reason || "尚未匯入門牌";
      }
      aoa.push([
        v.fileRow != null ? v.fileRow : "",
        v.name,
        v.zone,
        v.net,
        v.birthMonth,
        v.address,
        failKindLabel(kind),
        reason,
        v.xrefOld || c.xrefOld || "",
        v.xrefNew || c.xrefNew || ""
      ]);
    });
    downloadXlsxRows("訪視對象-對位失敗-" + new Date().toISOString().slice(0, 10) + ".xlsx", aoa, "對位失敗").then(function () {
      toast("已匯出失敗／未對位 " + rows.length + " 筆（含失敗類型）", "ok", 2800);
    }).catch(function (e) {
      toast((e && e.message) || "無法匯出 Excel", "error", 4000);
    });
  }

  function exportVisitCsv() {
    if (!visitQueue.length) {
      toast("排訪清單無資料可匯出", "error", 2800);
      return;
    }
    var lines = ["序,責任區,服務網,生日月,姓名,完整地址,已訪"];
    for (var i = 0; i < visitQueue.length; i++) {
      var it = visitQueue[i];
      var v = findVeteranById(it.id);
      if (!v) continue;
      function esc(s) {
        s = String(s == null ? "" : s);
        if (/[",\n]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
        return s;
      }
      lines.push([
        String(i + 1),
        esc(v.zone),
        esc(v.net),
        esc(v.birthMonth),
        esc(v.name),
        esc(v.address),
        it.visited ? "Y" : "N"
      ].join(","));
    }
    var blob = new Blob(["\ufeff" + lines.join("\n")], { type: "text/csv;charset=utf-8" });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "排訪清單-" + new Date().toISOString().slice(0, 10) + ".csv";
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
    toast("已匯出排訪 CSV", "ok", 2500);
  }

  function pickCol(headers, names) {
    var i, j, h, n;
    for (j = 0; j < names.length; j++) {
      n = names[j];
      for (i = 0; i < headers.length; i++) {
        h = headers[i].replace(/\s+/g, "");
        if (h === n || h.toLowerCase() === n.toLowerCase()) return headers[i];
      }
    }
    for (j = 0; j < names.length; j++) {
      n = names[j];
      for (i = 0; i < headers.length; i++) {
        if (headers[i].indexOf(n) >= 0) return headers[i];
      }
    }
    return "";
  }

  function veteranField(row, keys) {
    var i, j, ks;
    for (i = 0; i < keys.length; i++) {
      if (row[keys[i]] != null && String(row[keys[i]]).trim() !== "") return String(row[keys[i]]).trim();
    }
    ks = Object.keys(row);
    for (j = 0; j < keys.length; j++) {
      for (i = 0; i < ks.length; i++) {
        if (ks[i].indexOf(keys[j]) >= 0 && String(row[ks[i]]).trim()) return String(row[ks[i]]).trim();
      }
    }
    return "";
  }

  function matchOne(addr) {
    addr = String(addr || "");
    if (!doorReady) return { status: "pend", reason: "尚未匯入門牌", lat: null, lng: null, aliasNote: "", failKind: "no-pack", xrefNew: "", xrefOld: "" };

    var townLi = extractTownLi(addr);
    var alias = townLi ? lookupLiAlias(townLi.town, townLi.li) : null;
    var aliasNote = "";
    var workAddr = addr;
    var applied = false;

    if (alias && alias.ambiguous) {
      aliasNote = "疑似舊里：" + alias.old + "→請擇一：" + alias.news.join("／");
      /* P0：一對多不自動選里名；門牌仍以原址（去里）嘗試 */
    } else if (alias && !alias.ambiguous && alias.news.length === 1) {
      workAddr = applyLiAliasToAddr(addr, alias);
      aliasNote = "已套用舊里對照：" + alias.old + "→" + alias.news[0];
      applied = true;
    }

    if (!hasDoorNumber(workAddr) && !hasDoorNumber(addr)) {
      var c0 = classifyAddrFail(addr, alias);
      return {
        status: "fail",
        reason: c0.kind === "no-number" ? (applied ? aliasNote + "；無門牌號碼" : c0.reason) : c0.reason,
        lat: null,
        lng: null,
        aliasNote: aliasNote,
        failKind: c0.kind,
        xrefNew: c0.xrefNew,
        xrefOld: c0.xrefOld
      };
    }

    var tryAddrs = [workAddr];
    if (workAddr !== addr) tryAddrs.push(addr);

    var hit = null;
    var hitHow = "";
    var i, keys, k;
    for (i = 0; i < tryAddrs.length && !hit; i++) {
      keys = exactKeyVariants(tryAddrs[i]);
      for (k = 0; k < keys.length; k++) {
        if (doorExact[keys[k]]) {
          hit = doorExact[keys[k]];
          hitHow = k === 0 && i === 0 ? "exact" : "variant";
          break;
        }
      }
    }
    if (hit) {
      var okReason = "";
      if (applied) okReason = aliasNote;
      else if (alias && alias.ambiguous) okReason = aliasNote;
      if (hitHow === "variant" && !okReason) okReason = "放寬門牌對位";
      return {
        status: hitHow === "exact" ? "ok" : "low",
        lat: hit.lat,
        lng: hit.lng,
        reason: hitHow === "exact" ? okReason : (okReason ? okReason + "；放寬門牌對位" : "放寬門牌對位"),
        aliasNote: aliasNote
      };
    }

    var fz = null;
    for (i = 0; i < tryAddrs.length && !fz; i++) {
      keys = fuzzyKeyVariants(tryAddrs[i]);
      for (k = 0; k < keys.length; k++) {
        if (keys[k] && doorFuzzy[keys[k]]) {
          fz = doorFuzzy[keys[k]];
          break;
        }
      }
    }
    if (fz) {
      var lowReason = "路名＋號模糊";
      if (applied) lowReason = aliasNote + "；" + lowReason;
      else if (alias && alias.ambiguous) lowReason = aliasNote + "；" + lowReason;
      return { status: "low", lat: fz.lat, lng: fz.lng, reason: lowReason, aliasNote: aliasNote };
    }

    var classified = classifyAddrFail(addr, alias);
    return {
      status: "fail",
      reason: classified.reason,
      lat: null,
      lng: null,
      aliasNote: aliasNote,
      failKind: classified.kind,
      xrefNew: classified.xrefNew,
      xrefOld: classified.xrefOld
    };
  }

  function ensureVetLayerOn(forceToast) {
    var vetLayer = $("vac-layer-vet");
    if (!vetLayer) return;
    ensureCluster();
    if (!vetLayer.checked) {
      vetLayer.checked = true;
      cluster.addTo(map);
      if (forceToast || !vetLayerToastShown) {
        vetLayerToastShown = true;
        toast("已重新開啟訪視對象圖層", "ok", 2800);
      }
    } else if (cluster && map && !map.hasLayer(cluster)) {
      cluster.addTo(map);
    }
  }

  async function rematchAll(quiet) {
    if (!veterans.length) { renderVeteranList(); return; }
    if (!doorReady) {
      for (var i = 0; i < veterans.length; i++) {
        veterans[i].status = "pend";
        veterans[i].reason = "尚未匯入門牌";
        veterans[i].lat = null;
        veterans[i].lng = null;
        veterans[i].aliasNote = "";
        veterans[i].failKind = "no-pack";
        veterans[i].xrefNew = "";
        veterans[i].xrefOld = "";
      }
      setBanner("請先載入門牌包或匯入門牌CSV後再對位。", true);
      renderVeteranList();
      renderVisitQueue();
      refreshMarkers();
      return;
    }
    setBanner("", false);
    setProgress(true, "對位中…", 0);
    for (var i = 0; i < veterans.length; i++) {
      var r = matchOne(veterans[i].address);
      veterans[i].status = r.status;
      veterans[i].reason = r.reason;
      veterans[i].lat = r.lat;
      veterans[i].lng = r.lng;
      veterans[i].aliasNote = r.aliasNote || "";
      veterans[i].failKind = r.failKind || "";
      veterans[i].xrefNew = r.xrefNew || "";
      veterans[i].xrefOld = r.xrefOld || "";
      if (i % 200 === 0) {
        setProgress(true, "對位中… " + i + "/" + veterans.length, (i / veterans.length) * 100);
        await yieldUI();
      }
    }
    setProgress(false);
    ensureVetLayerOn(!quiet);
    renderVeteranList();
    renderVisitQueue();
    refreshMarkers();
    scheduleVisitRoute();
    var s = stats();
    if (!quiet) toast("對位完成：已定位 " + s.a + "、低信心 " + s.b + "、失敗 " + s.c + "、共 " + s.n, "ok", 4500);
    persistState();
  }

  async function onVeteranFile(ev) {
    var f = ev.target.files && ev.target.files[0];
    ev.target.value = "";
    if (!f) return;
    var fname = String(f.name || "").toLowerCase();
    if (/\.ods$/.test(fname)) {
      toast("不支援 ODS。請另存成 .xlsx 或 CSV（第一張工作表、欄位與示範相同）。", "error", 6500);
      return;
    }
    setProgress(true, "讀取訪視檔…", 8);
    try {
      var buf = await f.arrayBuffer();
      var rows = [];
      var encLabel = "csv";
      var extraSheets = [];
      var headerStart = 0;
      if (/\.(xlsx|xls)$/.test(fname)) {
        await loadSheetJs();
        var xl = excelFirstSheetGrid(buf);
        extraSheets = xl.extra;
        rows = xl.grid;
        encLabel = "Excel「" + xl.name + "」";
      } else {
        var dec = decodeCsvBytes(buf);
        if (countRepl(dec.text) > 50 && dec.enc === "utf-8") {
          setProgress(false);
          toast("編碼無法可靠辨識，請另存 UTF-8 後再匯入。", "error", 6000);
          return;
        }
        rows = parseCsv(dec.text);
        encLabel = dec.enc;
      }
      var sliced = sliceFromVeteranHeader(rows);
      if (sliced.start < 0) {
        setProgress(false);
        var shown = (rows[0] || []).filter(function (h) { return String(h || "").trim(); }).join("、") || "（空白）";
        var extra = extraSheets.length ? " 此檔還有工作表：" + extraSheets.join("、") + "。只讀第一張，請把資料放到第一張或另存 CSV。" : " 請讓表頭列含「姓名」與「通訊地址」（或「地址」）。";
        toast("找不到「姓名」與「通訊地址」表頭。讀到：" + shown + "。" + extra, "error", 8000);
        return;
      }
      headerStart = sliced.start;
      var parsed = rowsToObjects(sliced.rows);
      if (!parsed.items.length) {
        setProgress(false);
        toast("檔案沒有資料列。", "error");
        return;
      }
      var out = [];
      var skipped = [];
      for (var i = 0; i < parsed.items.length; i++) {
        var row = parsed.items[i];
        var fileRow = headerStart + (row.__row || (i + 2));
        var name = veteranField(row, ["姓名", "名字", "name"]);
        var addr = veteranField(row, ["通訊地址", "地址", "address"]);
        if (!name && !addr) {
          skipped.push("第 " + fileRow + " 列：姓名與地址皆空白，已略過");
          continue;
        }
        if (!name || !addr) {
          skipped.push("第 " + fileRow + " 列：缺少" + (!name ? "姓名" : "通訊地址") + "，已略過");
          continue;
        }
        out.push({
          id: out.length + 1,
          fileRow: fileRow,
          name: name,
          zone: veteranField(row, ["責任區"]),
          net: veteranField(row, ["服務區", "服務網"]),
          birthMonth: parseBirthMonth(veteranField(row, ["生日月份", "出生月", "生日月", "birthMonth", "月份"])),
          address: addr,
          status: "pend",
          reason: "",
          aliasNote: "",
          failKind: "",
          xrefNew: "",
          xrefOld: "",
          lat: null,
          lng: null
        });
      }
      if (!out.length) {
        setProgress(false);
        toast("沒有可匯入的列。請確認每列都有姓名與通訊地址。", "error", 6000);
        if (skipped.length) doorNotice("匯入失敗列", skipped.join("\n"));
        return;
      }
      veterans = out;
      visitQueue = [];
      visitedList = [];
      persistVisitQueue();
      fillListFilters();
      setProgress(false);
      var msg = "已匯入訪視對象 " + out.length + " 筆（" + encLabel + "）。資料只在本機。";
      if (extraSheets.length) msg += " 僅讀第一張工作表。";
      if (skipped.length) msg += " 略過 " + skipped.length + " 列。";
      toast(msg, skipped.length ? "warn" : "ok", 4500);
      if (skipped.length) doorNotice("部分列未匯入", "合格 " + out.length + " 筆已匯入；下列略過：\n" + skipped.join("\n"));
      if (!doorReady) setBanner("請先載入內建門牌或匯入門牌CSV後再對位。", true);
      await rematchAll();
      renderVisitQueue();
      updateTodayProgress();
      scheduleVisitRoute();
    } catch (err) {
      setProgress(false);
      console.error(err);
      var msg = (err && err.message) ? String(err.message) : String(err || "unknown");
      toast("匯入失敗：" + msg.slice(0, 200), "error", 7000);
    }
  }

  function fillSelect(sel, headers, guessed) {
    sel.textContent = "";
    var o0 = document.createElement("option");
    o0.value = "";
    o0.textContent = "（無）";
    sel.appendChild(o0);
    headers.forEach(function (h) {
      var o = document.createElement("option");
      o.value = h;
      o.textContent = h;
      if (h === guessed) o.selected = true;
      sel.appendChild(o);
    });
  }

  async function onDoorFile(ev) {
    var f = ev.target.files && ev.target.files[0];
    ev.target.value = "";
    if (!f) return;
    if (f.size > 80 * 1024 * 1024) {
      toast("檔案過大。請匯入 kh_door_11509_part1–13 切片（勿一次載入整份約 107MB 門牌）。", "warn", 7000);
    }
    setProgress(true, "讀取門牌切片…", 10);
    try {
      var buf = await f.arrayBuffer();
      var dec = decodeCsvBytes(buf);
      var rows = parseCsv(dec.text);
      if (rows.length < 2) {
        setProgress(false);
        toast("門牌檔沒有資料列。", "error");
        return;
      }
      var headers = rows[0].map(function (h) { return String(h || "").trim(); });
      pendingDoorText = dec.text;
      var guessed = guessDoorMapping(headers);
      $("vac-v2-map-headers").textContent = (guessed.official
        ? "已偵測正式門牌欄（H-MAP-01）。預設：組合高雄市＋區名＋街路段＋巷弄號；橫／縱座標 TWD97→WGS84。"
        : "偵測欄位：") + " " + headers.join("、");
      fillSelect($("vac-v2-col-addr"), headers, guessed.addr);
      fillSelect($("vac-v2-col-lat"), headers, guessed.lat);
      fillSelect($("vac-v2-col-lng"), headers, guessed.lng);
      fillSelect($("vac-v2-col-x"), headers, guessed.x);
      fillSelect($("vac-v2-col-y"), headers, guessed.y);
      setProgress(false);
      $("vac-v2-mapmodal").classList.add("is-on");
    } catch (err) {
      setProgress(false);
      toast("門牌檔讀取失敗。", "error");
    }
  }

  function rowGet(row, keys) {
    var i, j, ks, k, h, val;
    if (!row) return "";
    ks = Object.keys(row);
    for (i = 0; i < keys.length; i++) {
      k = keys[i];
      if (row[k] != null && String(row[k]).trim() !== "") return String(row[k]).trim();
      for (j = 0; j < ks.length; j++) {
        h = String(ks[j]).replace(/\s+/g, "");
        if (h === k) {
          val = row[ks[j]];
          if (val != null && String(val).trim() !== "") return String(val).trim();
        }
      }
    }
    return "";
  }

  function cityFromCode(code) {
    code = String(code == null ? "" : code).trim();
    if (KH_CITY_BY_CODE[code]) return KH_CITY_BY_CODE[code];
    if (code === "64" || /^64/.test(code)) return "高雄市";
    return "";
  }

  function townFromCode(code) {
    code = String(code == null ? "" : code).trim();
    if (KH_TOWN_BY_CODE[code]) return KH_TOWN_BY_CODE[code];
    if (/^\d+\.0$/.test(code)) {
      code = code.replace(/\.0$/, "");
      if (KH_TOWN_BY_CODE[code]) return KH_TOWN_BY_CODE[code];
    }
    if (code.length === 5 && KH_TOWN_BY_CODE[code + "00"]) return KH_TOWN_BY_CODE[code + "00"];
    return "";
  }

  function withUnit(val, unit) {
    val = String(val || "").trim();
    if (!val) return "";
    return val.indexOf(unit) >= 0 ? val : val + unit;
  }

  function isOfficialDoorHeaders(headers) {
    var set = Object.create(null);
    (headers || []).forEach(function (h) {
      set[String(h || "").replace(/\s+/g, "")] = true;
    });
    return !!(set["橫座標"] && set["縱座標"] && set["街路段"] && set["鄉鎮市區代碼"]);
  }

  function guessDoorMapping(headers) {
    headers = headers || [];
    if (isOfficialDoorHeaders(headers)) {
      return {
        official: true,
        addr: "",
        lat: "",
        lng: "",
        x: pickCol(headers, ["橫座標"]),
        y: pickCol(headers, ["縱座標"])
      };
    }
    return {
      official: false,
      addr: pickCol(headers, ["完整地址", "地址", "門牌", "門牌地址", "address", "住址", "通訊地址"]),
      lat: pickCol(headers, ["緯度", "lat", "latitude", "WGS84Y", "wgs84_lat", "Y_WGS84", "北緯"]),
      lng: pickCol(headers, ["經度", "lng", "lon", "longitude", "WGS84X", "wgs84_lng", "X_WGS84", "東經"]),
      x: pickCol(headers, ["TWD97X", "TWD97_X", "TWD97-X", "橫座標", "TWD97x"]),
      y: pickCol(headers, ["TWD97Y", "TWD97_Y", "TWD97-Y", "縱座標", "TWD97y"])
    };
  }

  function composeAddr(row) {
    var cityCode = rowGet(row, ["省市縣市代碼"]);
    var townCode = rowGet(row, ["鄉鎮市區代碼"]);
    var city = rowGet(row, ["省市縣市名稱", "縣市", "縣市名稱", "CITY"]) || cityFromCode(cityCode) || "高雄市";
    var town = rowGet(row, ["鄉鎮市區名稱", "鄉鎮市區", "TOWN"]) || townFromCode(townCode);
    var road = rowGet(row, ["街路段", "路", "路街段名", "街路", "街", "ROAD"]);
    var area = rowGet(row, ["地區"]);
    var sec = rowGet(row, ["段", "SEGMENT"]);
    var lane = rowGet(row, ["巷", "LANE"]);
    var alley = rowGet(row, ["弄", "ALLEY"]);
    var no = rowGet(row, ["號", "門牌號", "NUMBER"]);
    var zhi = rowGet(row, ["之", "號之"]);
    if (!road && area) road = area;
    var s = city + town + road;
    if (sec) s += withUnit(sec, "段");
    if (lane) s += withUnit(lane, "巷");
    if (alley) s += withUnit(alley, "弄");
    if (no) {
      var n = String(no).trim();
      if (n.indexOf("號") < 0) n += "號";
      s += n;
    }
    if (zhi && String(no).indexOf("之") < 0) {
      s = s.replace(/號$/, "之" + String(zhi).replace(/^之/, "") + "號");
    }
    return s;
  }

  function extractLL(row, mapCols) {
    var lat = mapCols.lat ? Number(row[mapCols.lat]) : NaN;
    var lng = mapCols.lng ? Number(row[mapCols.lng]) : NaN;
    if (looksWgs84(lat, lng)) return { lat: lat, lng: lng };
    if (looksWgs84(lng, lat)) return { lat: lng, lng: lat };
    var x = mapCols.x ? Number(row[mapCols.x]) : NaN;
    var y = mapCols.y ? Number(row[mapCols.y]) : NaN;
    if (looksTwd97(x, y)) return twd97ToWgs84(x, y);
    if (looksTwd97(lat, lng)) return twd97ToWgs84(lat, lng);
    if (looksTwd97(lng, lat)) return twd97ToWgs84(lng, lat);
    return null;
  }

  function countDoorExact() {
    var n = 0;
    for (var k in doorExact) if (Object.prototype.hasOwnProperty.call(doorExact, k)) n++;
    return n;
  }

  function updateDoorStatusUi() {
    var el = $("vac-v2-door-status");
    if (!el) return;
    if (!doorReady) {
      el.textContent = "尚未載入全市門牌索引 — 請「載入內建門牌」或匯入門牌CSV";
      el.setAttribute("data-state", "empty");
      return;
    }
    var ver = doorMeta.version || "本機";
    var delta = doorMeta.lastDelta ? (" · 上次增量：" + doorMeta.lastDelta) : "";
    el.textContent = "門牌已就緒（" + ver + " · " + doorCount + " 鍵）" + delta;
    el.setAttribute("data-state", "ready");
  }

  function ingestDoorRows(items, mapCols, mode) {
    var exact, fuzzy;
    if (mode === "upsert") {
      exact = doorExact;
      fuzzy = doorFuzzy;
    } else {
      exact = Object.create(null);
      fuzzy = Object.create(null);
      resetDoorSuggest();
    }
    var ok = 0, skip = 0, updated = 0, added = 0;
    for (var i = 0; i < items.length; i++) {
      var row = items[i];
      var op = String(row.op || row.OP || row["操作"] || "").trim().toLowerCase();
      var addr = mapCols.addr ? String(row[mapCols.addr] || "") : composeAddr(row);
      var key = normalizeAddr(addr);
      if (op === "delete" || op === "del" || op === "刪除") {
        if (key && exact[key]) { delete exact[key]; updated++; }
        continue;
      }
      var ll = extractLL(row, mapCols);
      if (!addr || !ll || !key) { skip++; continue; }
      if (exact[key]) updated++;
      else added++;
      exact[key] = { lat: ll.lat, lng: ll.lng };
      indexDoorKey(key);
      var fk = fuzzyKey(addr);
      if (fk && !fuzzy[fk]) fuzzy[fk] = { lat: ll.lat, lng: ll.lng };
      ok++;
    }
    doorExact = exact;
    doorFuzzy = fuzzy;
    doorCount = countDoorExact();
    doorReady = doorCount > 0;
    return { ok: ok, skip: skip, updated: updated, added: added };
  }

  async function confirmDoorImport() {
    if (!pendingDoorText) return;
    var mapCols = {
      addr: $("vac-v2-col-addr").value,
      lat: $("vac-v2-col-lat").value,
      lng: $("vac-v2-col-lng").value,
      x: $("vac-v2-col-x").value,
      y: $("vac-v2-col-y").value
    };
    $("vac-v2-mapmodal").classList.remove("is-on");
    var parsed = rowsToObjects(parseCsv(pendingDoorText));
    pendingDoorText = null;
    var mode = pendingDoorMode || "replace";
    setProgress(true, mode === "upsert" ? "合併門牌異動…" : "建立門牌索引…", 0);
    await yieldUI();
    var stats = ingestDoorRows(parsed.items, mapCols, mode);
    setProgress(false);
    if (!stats.ok && mode !== "upsert") {
      toast("沒有成功索引的門牌列。請檢查地址與經緯度／TWD97 欄位。", "error", 6000);
      updateDoorStatusUi();
      return;
    }
    if (mode === "upsert") {
      doorMeta.lastDelta = new Date().toISOString().slice(0, 10) + "（異動 CSV）";
      toast("已合併 " + stats.added + " 筆／更新 " + stats.updated + " 筆" + (stats.skip ? ("，略過 " + stats.skip) : "") + "。資料只在本機。", "ok", 4500);
    } else {
      doorMeta.version = doorMeta.version || "切片匯入";
      doorMeta.source = "slice";
      toast("門牌索引 " + stats.ok + " 筆" + (stats.skip ? ("，略過 " + stats.skip) : "") + "。資料只在本機。", "ok", 4000);
    }
    doorMeta.exactCount = doorCount;
    updateDoorStatusUi();
    await persistState();
    await rematchAll();
  }

  function applyShardArray(arr, kind) {
    if (!Array.isArray(arr)) return 0;
    var n = 0;
    for (var i = 0; i < arr.length; i++) {
      var row = arr[i];
      if (!row || row.length < 3) continue;
      var key = String(row[0] || "");
      var lat = Number(row[1]);
      var lng = Number(row[2]);
      if (!key || !isFinite(lat) || !isFinite(lng)) continue;
      if (kind === "exact") {
        doorExact[key] = { lat: lat, lng: lng };
        indexDoorKey(key);
      } else if (kind === "fuzzy" && !doorFuzzy[key]) doorFuzzy[key] = { lat: lat, lng: lng };
      n++;
    }
    return n;
  }

  async function ingestDoorPackFromManifest(manifest, loadShardFn) {
    var shards = (manifest && manifest.shards) || [];
    if (!shards.length) throw new Error("manifest 無 shards");
    doorExact = Object.create(null);
    doorFuzzy = Object.create(null);
    resetDoorSuggest();
    for (var i = 0; i < shards.length; i++) {
      var sh = shards[i];
      setProgress(true, "載入門牌索引中… 第 " + (i + 1) + "／" + shards.length + " 片", (i / shards.length) * 100);
      var data = await loadShardFn(sh.file);
      applyShardArray(data, sh.kind || "exact");
      await yieldUI();
    }
    doorCount = countDoorExact();
    doorReady = doorCount > 0;
    doorMeta = {
      version: String(manifest.version || "door-pack"),
      source: "pack",
      lastDelta: doorMeta.lastDelta || "",
      exactCount: doorCount,
      fuzzyCount: manifest.fuzzyCount || 0
    };
    setProgress(true, "寫入本機索引…", 95);
    await persistState();
    setProgress(false);
    updateDoorStatusUi();
    setBanner("", false);
    toast("門牌已就緒（" + doorCount + " 鍵）。資料只在本機。", "ok", 4200);
    if (veterans.length) await rematchAll();
  }

  async function tryFetchDoorPack(base) {
    var raw = String(base || "");
    var direct = /door-pack-demo/i.test(raw) || /(?:^|\/)door-pack\/?$/i.test(raw);
    function packUrl(file) {
      var u = raw.replace(/\/?$/, "/");
      if (direct) return u + file;
      u = u.replace(/\/pack\/?$/, "/");
      var q = "action=pack&file=" + encodeURIComponent(file);
      if (doorPassSession) {
        var payload = btoa(unescape(encodeURIComponent(JSON.stringify({ password: doorPassSession, action: "pack", file: file }))))
          .replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
        q += "&b=" + encodeURIComponent(payload);
      }
      return u + (u.indexOf("?") >= 0 ? "&" : "?") + q;
    }
    var res = await fetch(packUrl("manifest.json"), {
      cache: "no-store",
      credentials: "include",
      headers: doorPassSession ? { "x-vac-door-pass": doorPassSession } : {},
    });
    var manifest = null;
    try { manifest = await res.json(); } catch (e) { manifest = null; }
    if (!res.ok || !manifest || manifest.ok === false || !manifest.shards) {
      var err = new Error((manifest && manifest.error) || "no manifest");
      err.status = res.status || 404;
      throw err;
    }
    await ingestDoorPackFromManifest(manifest, async function (file) {
      var r = await fetch(packUrl(file), {
        cache: "no-store",
        credentials: "include",
        headers: doorPassSession ? { "x-vac-door-pass": doorPassSession } : {},
      });
      if (!r.ok) {
        var e2 = new Error("shard " + file);
        e2.status = r.status;
        throw e2;
      }
      return r.json();
    });
    return true;
  }

  var doorPassMode = "verify";
  var doorPassAfter = null;

  function doorNotice(title, body) {
    var t = $("vac-v2-notice-title");
    var b = $("vac-v2-notice-body");
    var m = $("vac-v2-notice-modal");
    if (t) t.textContent = title;
    if (b) b.textContent = body;
    if (m) m.classList.add("is-on");
  }

  var doorPassSession = "";
  var doorApiOkBase = "";

  var doorApiOriginCache = null;

  async function doorApiBases() {
    var bases = ["/api/vac-door/", "/vac-door-gate/"];
    if (doorApiOriginCache && doorApiOriginCache.length) {
      return bases.concat(doorApiOriginCache);
    }
    var extra = [];
    try {
      var r = await fetch("vac-door-api.json", { cache: "no-store" });
      if (r.ok) {
        var j = await r.json();
        (j.origins || []).forEach(function (o) {
          var origin = String(o || "").replace(/\/$/, "");
          if (!origin || origin === location.origin) return;
          extra.push(origin + "/api/vac-door/");
          extra.push(origin + "/vac-door-gate/");
        });
      }
    } catch (e) {}
    doorApiOriginCache = extra;
    return bases.concat(extra);
  }

  async function doorApi(path, body) {
    function b64url(obj) {
      var s = JSON.stringify(obj);
      var b64 = btoa(unescape(encodeURIComponent(s)));
      return b64.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
    }
    function usable(data) {
      if (!data || !data._parsed) return false;
      if (data._status === 401 || data._status === 409 || data._status === 400 || data._status === 429) return true;
      return data._status >= 200 && data._status < 300;
    }
    async function call(base, method, headers, withQuery) {
      var root = String(base || "").replace(/\/?$/, "/");
      var abs = /^https?:\/\//i.test(root) ? root : (location.origin || "") + (root.charAt(0) === "/" ? root : "/" + root);
      var payload = body ? Object.assign({ action: path }, body) : { action: path };
      var u = abs;
      var q = "action=" + encodeURIComponent(path);
      if (withQuery) q += "&b=" + encodeURIComponent(b64url(payload));
      u += (u.indexOf("?") >= 0 ? "&" : "?") + q;
      var opts = { method: method, credentials: "include", headers: headers || {}, cache: "no-store" };
      if (method === "POST") {
        opts.headers["content-type"] = "application/json";
        opts.body = JSON.stringify(payload);
      } else if (body) {
        opts.headers["x-vac-door-body"] = JSON.stringify(payload);
      }
      var res;
      var text = "";
      try {
        res = await fetch(u, opts);
        text = await res.text();
      } catch (e) {
        return { ok: false, error: "無法連線", _ok: false, _status: 0, _parsed: false };
      }
      var data = {};
      var parsed = false;
      try {
        data = text ? JSON.parse(text) : {};
        parsed = !!(data && typeof data === "object");
      } catch (e) {
        data = { ok: false, error: "這個網址還沒接上門牌後端。請用對話預覽，或等 kcv 發佈含後端的版本。" };
      }
      if (!parsed) data.ok = false;
      data._status = res.status;
      data._parsed = parsed;
      data._ok = res.ok && parsed && data.ok !== false;
      data._base = base;
      return data;
    }
    var last = { ok: false, error: "這個網址還沒接上門牌後端。請改用對話裡的地圖預覽。", _ok: false, _status: 0, _parsed: false };
    var bases = await doorApiBases();
    var bi, data;
    for (bi = 0; bi < bases.length; bi++) {
      if (body) {
        data = await call(bases[bi], "GET", { "x-vac-door-body": JSON.stringify(body) }, true);
        if (usable(data)) { doorApiOkBase = bases[bi]; return data; }
        last = data;
        data = await call(bases[bi], "POST", {}, false);
        if (usable(data)) { doorApiOkBase = bases[bi]; return data; }
        last = data;
      } else {
        data = await call(bases[bi], "GET", {}, false);
        if (data._parsed && (typeof data.configured === "boolean" || data.ok === true || data._status === 200)) {
          doorApiOkBase = bases[bi];
          return data;
        }
        last = data;
      }
    }
    return last;
  }

  function closeDoorPassModal() {
    var m = $("vac-v2-pass-modal");
    if (m) m.classList.remove("is-on");
  }

  function setPassErr(msg) {
    var e = $("vac-v2-pass-err");
    if (e) e.textContent = msg || "";
  }

  function applyDoorPassModalLayout() {
    var title = $("vac-v2-pass-title");
    var lead = $("vac-v2-pass-lead");
    var oldLab = $("vac-v2-pass-old-lab");
    var newLab = $("vac-v2-pass-new-lab");
    var cfLab = $("vac-v2-pass-cf-lab");
    var staffLab = $("vac-v2-pass-staff-lab");
    function setLab(node, name) {
      if (!node) return;
      var t = node.firstChild;
      if (t && t.nodeType === 3) t.textContent = name;
    }
    if (doorPassMode === "setup") {
      if (title) title.textContent = "管理者設定密碼";
      if (lead) lead.textContent = "請設定兩組不同密碼。同仁用「載入內建門牌」輸入同仁共用密碼。至少 8 個字。";
      if (oldLab) oldLab.style.display = "none";
      if (newLab) { newLab.style.display = ""; setLab(newLab, "設定管理者新密碼"); }
      if (cfLab) cfLab.style.display = "";
      if (staffLab) staffLab.style.display = "";
    } else if (doorPassMode === "change-auth") {
      if (title) title.textContent = "管理者";
      if (lead) lead.textContent = "須先通過目前管理者密碼，才能變更兩組密碼。";
      if (oldLab) oldLab.style.display = "";
      if (newLab) newLab.style.display = "none";
      if (cfLab) cfLab.style.display = "none";
      if (staffLab) staffLab.style.display = "none";
    } else if (doorPassMode === "change") {
      if (title) title.textContent = "管理者設定密碼";
      if (lead) lead.textContent = "管理者密碼與同仁密碼必須不同。變更後舊密碼立即失效。";
      if (oldLab) oldLab.style.display = "none";
      if (newLab) { newLab.style.display = ""; setLab(newLab, "設定管理者新密碼"); }
      if (cfLab) cfLab.style.display = "";
      if (staffLab) staffLab.style.display = "";
    } else {
      if (title) title.textContent = "載入內建門牌";
      if (lead) lead.textContent = "同仁請輸入共用密碼，即可載入全市門牌。";
      if (oldLab) oldLab.style.display = "none";
      if (newLab) { newLab.style.display = ""; setLab(newLab, "同仁共用密碼"); }
      if (cfLab) cfLab.style.display = "none";
      if (staffLab) staffLab.style.display = "none";
    }
  }

  function openDoorPassModal(mode, after) {
    doorPassMode = mode || "verify";
    doorPassAfter = after || null;
    var oldIn = $("vac-v2-pass-old");
    var newIn = $("vac-v2-pass-new");
    var cfIn = $("vac-v2-pass-cf");
    var staffIn = $("vac-v2-pass-staff");
    if (oldIn) oldIn.value = "";
    if (newIn) newIn.value = "";
    if (cfIn) cfIn.value = "";
    if (staffIn) staffIn.value = "";
    setPassErr("");
    applyDoorPassModalLayout();
    var m = $("vac-v2-pass-modal");
    if (m) m.classList.add("is-on");
    setTimeout(function () {
      var focus = newIn;
      if (doorPassMode === "change-auth") focus = oldIn;
      if (focus) try { focus.focus(); } catch (e) {}
    }, 40);
  }

  function openDoorPassModal(mode, after) {
    doorPassMode = mode || "verify";
    doorPassAfter = after || null;
    var oldIn = $("vac-v2-pass-old");
    var newIn = $("vac-v2-pass-new");
    var cfIn = $("vac-v2-pass-cf");
    if (oldIn) oldIn.value = "";
    if (newIn) newIn.value = "";
    if (cfIn) cfIn.value = "";
    setPassErr("");
    applyDoorPassModalLayout();
    var m = $("vac-v2-pass-modal");
    if (m) m.classList.add("is-on");
    setTimeout(function () {
      var focus = (doorPassMode === "change" || doorPassMode === "change-auth") ? oldIn : newIn;
      if (doorPassMode === "change") focus = newIn;
      if (focus) try { focus.focus(); } catch (e) {}
    }, 40);
  }

  async function submitDoorPassModal() {
    var oldIn = $("vac-v2-pass-old");
    var newIn = $("vac-v2-pass-new");
    var cfIn = $("vac-v2-pass-cf");
    var staffIn = $("vac-v2-pass-staff");
    var oldPw = oldIn ? oldIn.value : "";
    var pw = newIn ? newIn.value : "";
    var cf = cfIn ? cfIn.value : "";
    var staffPw = staffIn ? staffIn.value : "";
    setPassErr("");
    try {
      var data;
      if (doorPassMode === "setup") {
        if (pw.length < 8) { setPassErr("管理者密碼至少 8 個字"); return; }
        if (pw !== cf) { setPassErr("兩次管理者密碼不一致"); return; }
        if (staffPw.length < 8) { setPassErr("同仁密碼至少 8 個字"); return; }
        if (pw === staffPw) { setPassErr("管理者密碼與同仁密碼必須不同"); return; }
        data = await doorApi("setup", { adminPassword: pw, password: pw, confirm: cf, staffPassword: staffPw });
      } else if (doorPassMode === "change-auth") {
        if (!oldPw) { setPassErr("請輸入目前管理者密碼"); return; }
        data = await doorApi("verify", { password: oldPw, role: "admin" });
        if (!data._ok || data.ok === false) {
          setPassErr(data.error || "目前管理者密碼不正確");
          return;
        }
        doorPassSession = oldPw;
        doorPassMode = "change";
        applyDoorPassModalLayout();
        setPassErr("");
        var newFocus = $("vac-v2-pass-new");
        if (newFocus) try { newFocus.focus(); } catch (e) {}
        return;
      } else if (doorPassMode === "change") {
        if (pw.length < 8) { setPassErr("管理者密碼至少 8 個字"); return; }
        if (pw !== cf) { setPassErr("兩次管理者密碼不一致"); return; }
        if (staffPw.length < 8) { setPassErr("同仁密碼至少 8 個字"); return; }
        if (pw === staffPw) { setPassErr("管理者密碼與同仁密碼必須不同"); return; }
        data = await doorApi("change", { oldPassword: oldPw || doorPassSession, newPassword: pw, confirm: cf, staffPassword: staffPw });
      } else {
        if (!pw) { setPassErr("請輸入同仁共用密碼"); return; }
        data = await doorApi("verify", { password: pw, role: "staff" });
        var staffOk = data && data._ok && data.ok !== false && data.role !== "admin" && data.unlocked !== false;
        if (!staffOk) {
          await ensureDemoDoorPack();
          var lead = $("vac-v2-pass-lead");
          if (lead) lead.textContent = "請重新輸入同仁共用密碼。";
          setPassErr("密碼錯誤");
          if (newIn) { newIn.value = ""; try { newIn.focus(); } catch (e) {} }
          return;
        }
        doorPassSession = pw;
        closeDoorPassModal();
        await loadFullPackOrDemo(data);
        return;
      }
      if (!data._ok || data.ok === false) {
        setPassErr(data.error || ("無法驗證密碼" + (data._status ? "（" + data._status + "）" : "")));
        return;
      }
      closeDoorPassModal();
      if (doorPassMode === "verify") doorPassSession = pw;
      if (doorPassMode === "change") {
        toast(
          data.durable === false
            ? "新密碼已在目前連線生效。kcv 雲端無法永久存檔，重新整理後可能回到舊密碼。請在對話預覽設定後再發佈。"
            : "兩組密碼已更新。同仁請用「載入內建門牌」輸入新的同仁共用密碼。舊密碼已失效。",
          data.durable === false ? "warn" : "ok",
          6500
        );
      } else if (doorPassMode === "setup") {
        toast(
          data.durable === false
            ? "密碼已在目前連線生效。kcv 雲端無法永久存檔，請在對話預覽設定後再發佈。"
            : "兩組密碼已設定。同仁請用「載入內建門牌」輸入同仁共用密碼。",
          data.durable === false ? "warn" : "ok",
          5500
        );
      }
      if (typeof doorPassAfter === "function") {
        var fn = doorPassAfter;
        doorPassAfter = null;
        await fn(data);
      }
    } catch (e) {
      setPassErr("無法連線，請稍後再試");
    }
  }

  async function ensureDemoDoorPack() {
    if (doorReady && doorCount > 0 && doorCount <= 800) return;
    try {
      await tryFetchDoorPack("./door-pack-demo/");
    } catch (e) {
      try { await tryFetchDoorPack("door-pack-demo/"); } catch (e2) {}
    }
  }

  async function loadDemoDoorPack(reasonTitle, reasonBody) {
    await ensureDemoDoorPack();
    doorNotice(reasonTitle, reasonBody);
  }

  function showStaffPassRetry() {
    if (doorPassMode !== "verify") openDoorPassModal("verify", function (data) { return loadFullPackOrDemo(data); });
    var lead = $("vac-v2-pass-lead");
    if (lead) lead.textContent = "請重新輸入同仁共用密碼。";
    setPassErr("密碼錯誤");
    var newIn = $("vac-v2-pass-new");
    if (newIn) { newIn.value = ""; try { newIn.focus(); } catch (e) {} }
  }

  async function loadFullPackOrDemo(apiData) {
    var lastStatus = 0;
    if (apiData && apiData.hasFullPack) {
      var bases = ["/api/vac-door/", "/vac-door-gate/"];
      var b = (apiData && apiData._base) || doorApiOkBase;
      if (b) {
        var packBase = String(b).replace(/\/?$/, "/");
        packBase = packBase.replace(/pack\/?$/, "");
        if (/^https?:\/\//i.test(packBase) || packBase.charAt(0) === "/") bases.unshift(packBase);
      }
      for (var i = 0; i < bases.length; i++) {
        try {
          await tryFetchDoorPack(bases[i]);
          return;
        } catch (e) {
          lastStatus = (e && e.status) || lastStatus;
        }
      }
    }
    await ensureDemoDoorPack();
    if (lastStatus === 401 || lastStatus === 403) {
      showStaffPassRetry();
      return;
    }
    doorNotice(
      "目前無完整門牌索引",
      "此網站沒有完整門牌檔，已載入試用 500 鍵。"
    );
  }

  async function tryLocalDoorPack() {
    try {
      await tryFetchDoorPack("./door-pack/");
      return true;
    } catch (e) {
      try {
        await tryFetchDoorPack("door-pack/");
        return true;
      } catch (e2) {
        return false;
      }
    }
  }

  async function loadDoorPackFlow() {
    if (doorReady && doorCount > 1000) {
      if (!window.confirm("本機已有門牌索引（" + doorCount + " 鍵）。仍要重新載入門牌包？")) return;
    }
    setProgress(true, "確認共用密碼…", 5);
    var st;
    try {
      st = await doorApi("status");
    } catch (e) {
      setProgress(true, "讀取本機門牌包…", 8);
      if (await tryLocalDoorPack()) return;
      setProgress(false);
      await loadDemoDoorPack(
        "這個網址沒有完整門牌服務",
        "請改用對話裡的地圖預覽載入全市門牌。kcv 發佈含後端後即可使用同一組密碼。"
      );
      return;
    }
    if (!st || !st._parsed) {
      setProgress(true, "讀取本機門牌包…", 8);
      if (await tryLocalDoorPack()) return;
      setProgress(false);
      await loadDemoDoorPack(
        "這個網址還沒接上門牌後端",
        "對話預覽可以驗證密碼並載入全市門牌。kcv 需發佈含後端的版本後，即可與預覽使用同一組密碼。"
      );
      return;
    }
    if (!st.configured) {
      setProgress(false);
      doorNotice("尚未設定密碼", "請管理者先按「管理者」設定兩組不同密碼。同仁請稍後用「載入內建門牌」輸入同仁共用密碼。");
      return;
    }
    setProgress(false);
    openDoorPassModal("verify", function (data) { return loadFullPackOrDemo(data); });
  }

  async function onDoorPackFiles(ev) {
    var files = ev.target.files;
    if (!files || !files.length) return;
    try {
      setProgress(true, "載入門牌索引中…", 5);
      var byName = Object.create(null);
      for (var i = 0; i < files.length; i++) byName[files[i].name] = files[i];
      var manFile = byName["manifest.json"];
      if (!manFile) {
        toast("未找到 manifest.json。請多選門牌包內所有 JSON。", "error", 5000);
        setProgress(false);
        return;
      }
      var manifest = JSON.parse(await manFile.text());
      await ingestDoorPackFromManifest(manifest, async function (name) {
        var f = byName[name];
        if (!f) throw new Error("缺少分片 " + name);
        return JSON.parse(await f.text());
      });
    } catch (err) {
      setProgress(false);
      toast("門牌包載入失敗：" + (err && err.message ? err.message : "未知錯誤"), "error", 6000);
      updateDoorStatusUi();
    }
    ev.target.value = "";
  }

  function openWipeModal() {
    var cb = $("vac-v2-wipe-door");
    if (cb) cb.checked = false;
    $("vac-v2-wipe-modal").classList.add("is-on");
  }

  async function confirmWipePii() {
    var clearDoor = $("vac-v2-wipe-door") && $("vac-v2-wipe-door").checked;
    $("vac-v2-wipe-modal").classList.remove("is-on");
    veterans = [];
    visitQueue = [];
    visitedList = [];
    persistVisitQueue();
    visitRouteSegs = [];
    if (visitRouteLayer) visitRouteLayer.clearLayers();
    cancelCustomLocate(true);
    clearMyPositionLayers();
    myPosKind = null;
    clearCustomPosStorage();
    if (cluster) cluster.clearLayers();
    if (clearDoor) {
      doorExact = Object.create(null);
      doorFuzzy = Object.create(null);
      resetDoorSuggest();
      doorCount = 0;
      doorReady = false;
      doorMeta = { version: "", source: "", lastDelta: "", exactCount: 0, fuzzyCount: 0 };
      await idbClearAll();
      toast("已清除訪視對象、自訂位置與門牌索引。", "ok");
    } else {
      try {
        await idbPut("veterans", "all", []);
        await idbPut("meta", "info", {
          doorCount: doorCount,
          doorReady: doorReady,
          doorMeta: doorMeta,
          t: Date.now()
        });
      } catch (e) {}
      toast("已清除訪視對象與自訂位置（門牌索引保留）。", "ok");
    }
    fillListFilters();
    renderVeteranList();
    renderVisitQueue();
    renderDoneList();
    updateTodayProgress();
    scheduleVisitRoute();
    setBanner(doorReady ? "" : "尚未載入全市門牌索引", !doorReady);
    updateDoorStatusUi();
  }

  async function wipePii() {
    openWipeModal();
  }

  async function boot() {
    map = findMap();
    if (!map) {
      setTimeout(boot, 50);
      return;
    }
    try {
      var m = localStorage.getItem("vac-v2-mask-name");
      if (m === "0") maskName = false;
    } catch (e) {}
    buildChrome();
    if ($("vac-v2-mask")) $("vac-v2-mask").checked = maskName;
    bindUi();
    measureLayer = L.layerGroup().addTo(map);
    ensureCluster();
    map.getContainer().addEventListener("pointerdown", onMeasurePtrDown, true);
    map.getContainer().addEventListener("touchstart", onMeasurePtrDown, { capture: true, passive: true });
    map.getContainer().addEventListener("click", onMapClickCapture, true);
    watchTiles();
    await loadLiAlias();
    await loadLiDoorXref();
    await restoreState();
    try {
      var pan = localStorage.getItem(LS_VISIT_PANEL);
      if (pan === "0") showVisitPanel = false;
      var rsm = localStorage.getItem(LS_ROUTE_START);
      if (rsm === "first" || rsm === "mypos") routeStartMode = rsm;
      if (localStorage.getItem(LS_TOOLS) === "1") setToolsCollapsed(true);
      else if (localStorage.getItem(LS_TOOLS) !== "0" && window.innerWidth < 1100) setToolsCollapsed(true);
    } catch (e) {}
    if ($("vac-v2-start-first")) $("vac-v2-start-first").checked = routeStartMode === "first";
    restoreListFilters();
    restoreVisitQueue();
    setRightTab("visit");
    fillListFilters();
    applyVisitPanelVis();
    renderVeteranList();
    renderVisitQueue();
    renderDoneList();
    refreshMarkers();
    updateTodayProgress();
    var saved = loadCustomPos();
    if (saved) {
      placeMyPosition(saved.lat, saved.lng, saved.addr ? "addr" : "custom", 0, saved.addr || "");
    } else {
      scheduleVisitRoute();
      updateOptimizeEnabled();
    }
    updateDoorStatusUi();
    if (!doorReady) setBanner("尚未載入全市門牌索引 — 請按「載入內建門牌包」或匯入門牌CSV。", true);
    else if (veterans.length) {
      setBanner("", false);
      await rematchAll(true);
    }
    updateMetrics();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  window.__vacV2 = {
    version: "2.3.10",
    OSRM_ENDPOINT: OSRM_ENDPOINT,
    normalizeAddr: normalizeAddr,
    fuzzyKey: fuzzyKey,
    extractTownLi: extractTownLi,
    lookupLiAlias: lookupLiAlias,
    applyLiAliasToAddr: applyLiAliasToAddr,
    lookupLiDoorXref: lookupLiDoorXref,
    classifyAddrFail: classifyAddrFail,
    getLiXrefCount: function () { return Object.keys(liXrefExact).length; },
    parseLiAliasCsv: parseLiAliasCsv,
    matchOne: matchOne,
    hasDoorNumber: hasDoorNumber,
    confirmAddrStart: confirmAddrStart,
    getLiAliasRows: function () { return liAliasRows.slice(); },
    haversineKm: haversineKm,
    twd97ToWgs84: twd97ToWgs84,
    looksTwd97: looksTwd97,
    looksWgs84: looksWgs84,
    composeAddr: composeAddr,
    cityFromCode: cityFromCode,
    townFromCode: townFromCode,
    isOfficialDoorHeaders: isOfficialDoorHeaders,
    guessDoorMapping: guessDoorMapping,
    extractLL: extractLL,
    etaMinutes: function (km, sp) {
      var old = speedKmh;
      if (sp) speedKmh = sp;
      var m = etaMinutes(km);
      speedKmh = old;
      return m;
    },
    getDoorMeta: function () { return doorMeta; },
    countDoorExact: countDoorExact,
    getVisitQueue: function () { return visitQueue.slice(); },
    optimizeVisitOrder: optimizeVisitOrder,
    parseBirthMonth: parseBirthMonth,
    VISIT_PENDING: VISIT_PENDING,
    VISIT_QUEUED: VISIT_QUEUED,
    VISIT_DONE: VISIT_DONE,
    OPTIMIZE_WARN_N: OPTIMIZE_WARN_N
  };
})();
