本目錄僅含合成示範資料，不含真實榮民／真實門牌個資。

- door-demo-slice.csv：舊欄名（完整地址＋WGS84），搭配 示範榮民.csv 驗對位
- door-demo-twd97.csv：舊欄名（地址＋TWD97_X/Y）
- door-official-header-demo.csv：正式欄名（H-MAP-01）2–3 列合成；橫／縱為 TWD97 TM2
- kh_town_codes.csv：高雄市鄉鎮市區代碼對照（非個資）
- li-alias-kh.csv：舊里→新里對照（行政區,舊里,新里,是否一對多,備註；非榮民個資）
- 示範榮民.csv：合成姓名／地址（含舊里一對一／一對多示範列）

正式作業請匯入 Drive「地圖」的 kh_door_11509_part1.csv … part13 切片（UTF-8，可含 BOM）。
門牌大檔約 107MB，請勿整包塞進瀏覽器。
